﻿-- Activity window — client-side static lists with server-time day filtering
-- Keeps original behavior; adds offline weekly/daily population and sorting.

-- Notes on time:
--  • We prefer server time (same for all players) if an API is available.
--  • Fallback is Philippines time (UTC+7) so the UI never shows empty lists.

----------------------------------------------------------------
-- UI handles
----------------------------------------------------------------
local uiapi = UIAPI
local win, container, day_list, pro_list, week_list, guide_list, multi_edit = nil, nil, nil, nil, nil, nil, nil
local curTime_text = nil

-- lists' in-memory mirrors
local daylist_cofig, prolist_config, weeklist_cofig, guidelist_cofig, curlist_config = {}, {}, {}, {}, {}

-- dynamic indices
local dcur_index, pcur_index, wcur_index, gcur_index = -1, -1, -1, -1
local hyper_text = ""
local flags, m_index = -1, -1

-- event button flash (kept as in stock file)
local event_btn, btn_flash_visible, btn_a, btn_r, btn_g, btn_b, count, not_click =
  nil, false, 0, 0, 0, 0, 0, true

----------------------------------------------------------------
-- Server time helpers (shared-time across all players)
----------------------------------------------------------------

-- Fallback offset: Philippines time (UTC+7)
local SERVER_UTC_OFFSET_SECONDS = -3 * 3600  -- ETAPA 148: horario de Brasilia/Fortaleza (UTC-3), igual ao servidor
-- Try to get a server epoch if the client exposes one.
-- We support several plausible names; if none exist, return nil.
local function try_get_server_epoch()
  local ok, val

  -- 1) GameAPI:GetServerTime() -> epoch seconds (preferred if exists)
  ok, val = pcall(function() return GameAPI and GameAPI.GetServerTime and GameAPI:GetServerTime() end)
  if ok and type(val) == "number" and val > 0 then return val end

  -- 2) GameAPI:GetServerUnixTime() -> epoch seconds
  ok, val = pcall(function() return GameAPI and GameAPI.GetServerUnixTime and GameAPI:GetServerUnixTime() end)
  if ok and type(val) == "number" and val > 0 then return val end

  -- 3) TimeAPI:GetServerTime() -> epoch seconds
  ok, val = pcall(function() return TimeAPI and TimeAPI.GetServerTime and TimeAPI:GetServerTime() end)
  if ok and type(val) == "number" and val > 0 then return val end

  return nil
end

-- Current timestamp in *server* time (epoch seconds).
local function server_now_epoch()
  local server_epoch = try_get_server_epoch()
  if server_epoch then return server_epoch end
  -- Fallback: UTC now + UTC+7 offset to approximate Philippines time
  local utc_now = os.time(os.date("!*t"))
  return utc_now + SERVER_UTC_OFFSET_SECONDS
end

-- Weekday in server time as 1..7 (Mon..Sun)
local function server_weekday()
  local t = os.date("*t", server_now_epoch())
  -- Lua's t.wday: 1=Sun..7=Sat; map to 1=Mon..7=Sun
  local map = { [1]=7,[2]=1,[3]=2,[4]=3,[5]=4,[6]=5,[7]=6 }
  return map[t.wday]
end

-- Optional: if you render server time somewhere else (e.g., MiniMap),
-- you may call its function to keep visuals consistent. Reference:
-- MinMapSetServerTime(str) from MiniMapProc.lua (sets a time label text). :contentReference[oaicite:0]{index=0}

----------------------------------------------------------------
-- Static lists
-- Type: 2 = Important Announcement, 3 = Weekly (also eligible for Today filtering)
-- Days array uses 1=Mon … 7=Sun
----------------------------------------------------------------
local STATIC_EVENTS = {
  -- 24/11/2026 (Claude): lista = a mesma do servidor (GameCore/Eventos55.inl), sem a lista do Origin.
  -- Aviso fixo do GodsDomain no lugar do "Brothers in Arms".
  {
    Type = 2,
    Name = "Welcome to GodsDomain Brasil",
    Link = "",
    Content =
      "Welcome to GodsDomain Brasil (Open Beta)!\n" ..
      "Report bugs on our Discord with a screenshot and how it happened.\n" ..
      "Thank you for helping us test the server!",
  },
  {
	Type = 3, Name = [==[GodsWar Marathon]==], Time = [==[Mon to Sat]==], Days = {1,2,3,4,5,6}, Link = "",
	Content = [==[ To give our players a taste of what the Ancient Greek Olympics must have been like, we have designed a round-the-city race! Come join the fun and win big rewards!                                                        |cff66FF00   Event Duration:           |cffFFFFFF         Anytime from Monday to Saturday                         |cff66FF00            Requirement:            |cffFFFFFF          Level 60 or above                           |cff66FF0R                         Rewards:             |cffFFFFFF              Each participator will be rewarded with 180 B-Gold for each of the first two times every day, and 90 B-Gold each time after that on that day.      ]==],
  },
  {
	Type = 3, Name = [==[Cursed Zone]==], Time = [==[Daily]==], Days = {1,2,3,4,5,6,7}, Link = "",
	Content = [==[   It is a place cursed by the Gods. Once people lived a pleasant life here, but they didn't respect the Gods or even worship them.                         |cff66FF00                               Event Duration:              |cffFFFFFF      8:00pm--9:00pm                                                      |cff66FF00                           Requirement:         |cffFFFFFF             Level 55-130                                                |cff66FF00         How to enter:                |cffFFFFFF                                        talk to the NPC Event Transporter                                |cff66FF00                                                             Event Rewards:        |cffFFFFFF                                                Enhanced Gear with Multi-attribute or Level which can be traded and more]==],
  },
  {
	Type = 3, Name = [==[The Spies Invaded]==], Time = [==[Daily]==], Days = {1,2,3,4,5,6,7}, Link = "",
	Content = [==[   During this event, players will be rewarded with rich Exp and Talent Points when they succeed in killing hostile spies in their  main city.                                              |cff66FF00   Event Duration:           |cffFFFFFF         12:30pm-12:40pm and 9:45pm-9:55pm every day                                |cff66FF00            Requirement:            |cffFFFFFF          All Players                                              |cff66FF00           How to enter:                |cffFFFFFF      A large number of spies, spy captains and spy masters will appear in both main cities and will drop various EXP  Stones and Talent Stones if they are killed.                                |cff66FF0R                         Rewards:             |cffFFFFFF               Exp and Talent Stone.]==],
  },
  {
	Type = 3, Name = [==[Hera's Labyrinth]==], Time = [==[Daily]==], Days = {1,2,3,4,5,6,7}, Link = "",
	Content = [==[   Zeus  dated his lover Europa, often making Hera jealous. In order to punish Europa, Hera trapped her on an isolated isle and created  complex Labyrinths on the isles to imprison her. It is difficult for common people to find her.
                                             |cff66FF00                       Event Duration:        |cffFFFFFF            All day                                               |cff66FF00               Requirement:                  |cffFFFFFF    Level 50 or above                                              |cff66FF00    How to enter:    |cffFFFFFF                 When players reach Level 50, they can find the Labyrinth Quest Envoy and accept the Labyrinth Quest. After that, talk to the NPC  Event Transporter then they can enter the Labyrinth.                 |cff66FF00                            Event Rewards:       |cffFFFFFF              Exp rewards are in accordance with the players'  level.]==],
  },
  {
	Type = 3, Name = [==[Zeus' Gift Event]==], Time = [==[Daily]==], Days = {1,2,3,4,5,6,7}, Link = "",
	Content = [==[   Many people are traveling from the various city-states of Greece to deliver their gifts to the almighty Zeus in hopes of his blessings. His tastes are quite peculiar, but these goods can be obtained by anyone willing to seek them out.                                             |cff66FF00      Event Duration:        |cffFFFFFF            All day                                                 |cff66FF00              Requirement:                  |cffFFFFFF    Level 55 or above                                                |cff66FF00    How to enter:    |cffFFFFFF                 In a conversation with [Event]Zeus Loyal Believer in Sparta or Athens, players can receive hints on what gifts Zeus currently desires. The right gifts will earn players Zeus blessings, in the form of rewards.                                    |cff66FF00                          Event Rewards:       |cffFFFFFF               Praying stone, EXP, and talent points]==],
  },
  {
	Type = 3, Name = [==[Search for the Lost Books]==], Time = [==[Daily]==], Days = {1,2,3,4,5,6,7}, Link = "",
	Content = [==[   Many books rumored to be filled with mysterious powers have been scattered all over the Greek lands. Some have even been rumored to have the secrets of the Wishing Pool recorded within their pages.                                                      |cff66FF00    Rules:    |cffFFFFFF                       Step 1: Obtain the Sheepskin Scrolls    Step 2: Exchange the Sheepskin Scrolls for Lost Book Chapters Step 3: Exchange the Lost Book Chapters for a Lost Book     |cff66FF00                                                         Event Rewards:       |cffFFFFFF               Exp, Talent Points, Crystals, Gems, Grains and much more!]==],
  },
  {
	Type = 3, Name = [==[Sign in Event]==], Time = [==[Mon to Sat]==], Days = {1,2,3,4,5,6}, Link = "",
	Content = [==[  From Monday to Saturday, Level 20+ players are qualified to claim Nameplate 1 to Nameplate 6 from the Faction Crier and exchange one Nameplate or  many Nameplates together for Exp and Talent Points.                                               |cff66FF00        Event Duration:            |cffFFFFFF        00:00-23:59                               |cff66FF00                                                    Requirement:                  |cffFFFFFF    All Level 20+ players                                  |cff66FF00            How to enter:               |cffFFFFFF      Athens,Spartan (142, -160)                                     |cff66FF00      Rewards:                        |cffFFFFFF   Level 20+  players can exchange one Nameplate or many Nameplates together for Exp and Talent Points.]==],
  },
  {
	Type = 3, Name = [==[Romance Island]==], Time = [==[Wed/Sat]==], Days = {3,6}, Link = "",
	Content = [==[   A map dedicated to the materials gathering activity has been introduced, and named Romance Island. The Event Transporter in the main city will transport any Level 70+ player onto the map.                                 |cff66FF00                       Event Duration:                |cffFFFFFF   8:30pm - 9:00pm Wed and Sat;     4:30pm - 5:00pm Sun                                   |cff66FF00               Requirement:                  |cffFFFFFF    Level 70 or above                                                |cff66FF00    How to enter:    |cffFFFFFF                 Talk to the NPC Event Transporter then you can enter the map                                         |cff66FF00                     Event Rewards:       |cffFFFFFF              all kinds of ingredients.    ]==],
  },
  {
	Type = 3, Name = [==[Pindus Battlefield]==], Time = [==[Wed/Sun]==], Days = {3,7}, Link = "",
	Content = [==[   Resourceful and daring Spartan troops discovered an abundance of wood and rare mine resources in the Pindus Mountains when the GodsWar broke out. After exiling the residents, the Spartan troops began to harvest the wood, exploit the mines and set up camp. The resources of the Pindus Mountains offered a mighty backup for Spartan expansion.
                                             |cff66FF00                       Event Duration:               |cffFFFFFF   11:00am to 11:45am Wed and Sun; 9:00pm to 9:45pm Sat                                                         |cff66FF00               Requirement:                  |cffFFFFFF    Level 60 or above                                              |cff66FF00    How to enter:    |cffFFFFFF                 talk to the NPC  Battlefield Transporter then you can enter the battlefield                              |cff66FF00                     Event Rewards:       |cffFFFFFF              Exp,talent points and reputation.    ]==],
  },
  {
	Type = 3, Name = [==[Trojan Expedition]==], Time = [==[Thu]==], Days = {4}, Link = "",
	Content = [==[Paris, the seductive prince of Troy, has lured Helen away to his city. Agamemnon, the great Greek leader, has decided to launch an attack on Troy to get her back. Warrior's from all over Greece have rallied to his banner...                     |cff66FF00               Event Duration:      |cffFFFFFF             8:00pm - 9:00pm, Thursdays
                              |cff66FF00                                       Requirement:                    |cffFFFFFF  Level 50 or above                               |cff66FF00                     How to enter:                |cffFFFFFF     Find the Event Transporter in the main city to be teleported to the map.                                 |cff66FF00                             Event Rewards:         |cffFFFFFF           Exp, guild gold, guild silver, title .          ]==],
  },
  {
	Type = 3, Name = [==[Rebuild Sicily]==], Time = [==[Fri]==], Days = {5}, Link = "",
	Content = [==[The once quiet and peaceful island of Sicily has lain in ruin for some time and the GodsWar team is looking to restore it. Get involved with the restoration to win lots of great prizes.                                            |cff66FF00               Event Duration:      |cffFFFFFF             10:00pm--0:00am                                          |cff66FF00                                       Requirement:                    |cffFFFFFF  Level 25 or above                               |cff66FF00                     How to enter:                |cffFFFFFF     When players reach Level 25, they can find the Sicily Refugee and accept the Purify Sicily Quest. After that, talk to the NPC Event Transporter then they can enter the Sicily Island.                                                  |cff66FF00                             Event Rewards:         |cffFFFFFF            TP rewards are in accordance with the players'  level .          ]==],
  },
  {
	Type = 3, Name = [==[Ni Mini Battlefield]==], Time = [==[Fri]==], Days = {5}, Link = "",
	Content = [==[   To foster the ability to counter potential danger, Athens and Sparta decided to send young soldiers to be drilled in the unfriendly environment of Ni Mini Valley.                                                 |cff66FF00                                              Event Duration:      |cffFFFFFF             9:45pm - 10:30pm,Fridays          7:00pm - 7:45pm, Sundays                                        |cff66FF00                                       Requirement:                    |cffFFFFFF  Level 60 - 89                                        |cff66FF00                Battle Rules:                |cffFFFFFF     Each player killed from the enemy faction will earn 1 point for your own faction as well as yourself.Participating players can claim their prizes straight after the battle is over.                                                   |cff6FF00                             Event Rewards:         |cffFFFFFF            Rep and Title.]==],
  },
  {
	Type = 3, Name = [==[Pindus Battlefield]==], Time = [==[Sat]==], Days = {6}, Link = "",
	Content = [==[   Resourceful and daring Spartan troops discovered an abundance of wood and rare mine resources in the Pindus Mountains when the GodsWar broke out. After exiling the residents, the Spartan troops began to harvest the wood, exploit the mines and set up camp. The resources of the Pindus Mountains offered a mighty backup for Spartan expansion.
                                             |cff66FF00                       Event Duration:               |cffFFFFFF   11:00am to 11:45am Wed and Sun; 9:00pm to 9:45pm Sat                                                         |cff66FF00               Requirement:                  |cffFFFFFF    Level 60 or above                                              |cff66FF00    How to enter:    |cffFFFFFF                 talk to the NPC  Battlefield Transporter then you can enter the battlefield                              |cff66FF00                     Event Rewards:       |cffFFFFFF              Exp,talent points and reputation.    ]==],
  },
  {
	Type = 3, Name = [==[Lelantine Farm]==], Time = [==[Sat]==], Days = {6}, Link = "",
	Content = [==[   The Battle of Lelantine Farm lasts 45 minutes, with the better scoring team being declared the winner. There is also the possibility of a tie. PvP mode is not allowed in  battle.                                             |cff66FF00             Event Duration:    |cffFFFFFF                10:45pm -11:30pm                                |cff66FF00                    Requirement:                   |cffFFFFFF   Level 31 or above                                                 |cff66FF00   How to enter:               |cffFFFFFF      Auto track to the Transporter NPC, and you will find the Battlefield Transporter next to it. Talk to the Battlefield Transporter to be teleported to the Battle of Lelantine                                        |cff66FF00    Event Rewards:|cffFFFFFF                     Exp, Pet Exp, B-Gold,  Pet Skill Book and much more.]==],
  },
  {
	Type = 3, Name = [==[Ni Mini Battlefield]==], Time = [==[Sun]==], Days = {7}, Link = "",
	Content = [==[   To foster the ability to counter potential danger, Athens and Sparta decided to send young soldiers to be drilled in the unfriendly environment of Ni Mini Valley.                                                 |cff66FF00                                              Event Duration:      |cffFFFFFF             9:45pm - 10:30pm,Fridays          7:00pm - 7:45pm, Sundays                                        |cff66FF00                                       Requirement:                    |cffFFFFFF  Level 60 - 89                                        |cff66FF00                Battle Rules:                |cffFFFFFF     Each player killed from the enemy faction will earn 1 point for your own faction as well as yourself.Participating players can claim their prizes straight after the battle is over.                                                   |cff6FF00                             Event Rewards:         |cffFFFFFF            Rep and Title.]==],
  },
  {
	Type = 3, Name = [==[Pan's Labyrinth]==], Time = [==[Sat and Sun]==], Days = {6,7}, Link = "",
	Content = [==[   A new activity to pets the participants' memory skills has been launched called Pan's Labyrinth! Getting in is easy, but escaping is the tough part...                                                |cff66FF00                       Event Duration:       |cffFFFFFF             12:00pm--6:00pm                                          |cff66FF00                                       Requirement:                    |cffFFFFFF  Level 70 or above                               |cff66FF00                     How to enter:                 |cffFFFFFF     Players must gather any three of the six parts of Pan's Invitation.Players can exchange them for a true copy of Pan's Invitation Letter.                               |cff66FF00                    Event Rewards:        |cffFFFFFF            The servants offer EXP, talent points, zodiac energy and other items.]==],
  },
  {
	Type = 3, Name = [==[Romance Island]==], Time = [==[Sun]==], Days = {7}, Link = "",
	Content = [==[   A map dedicated to the materials gathering activity has been introduced, and named Romance Island. The Event Transporter in the main city will transport any Level 70+ player onto the map.                                 |cff66FF00                       Event Duration:                |cffFFFFFF   8:30pm - 9:00pm Wed and Sat;     4:30pm - 5:00pm Sun                                   |cff66FF00               Requirement:                  |cffFFFFFF    Level 70 or above                                                |cff66FF00    How to enter:    |cffFFFFFF                 Talk to the NPC Event Transporter then you can enter the map                                       |cff66FF00                     Event Rewards:       |cffFFFFFF              all kinds of ingredients.    ]==],
  },
  {
	Type = 3, Name = [==[Treasure Land]==], Time = [==[Sun]==], Days = {7}, Link = "",
	Content = [==[   To help people get rid of poverty and disease, Hermes brought lots of treasures to the world. Zeus was very irritated when he found out and penalized Hermes. However, the treasures had been spread to the world, so Zeus created many monsters to take them back. The people did not give in and fought against the monsters in a place which is called Treasure Land.                                   |cff66FF00             Event Duration:    |cffFFFFFF                10:00pm--11:00pm                                |cff66FF00                    Requirement:                   |cffFFFFFF   Level 60-130                                                    |cff66FF00   How to enter:               |cffFFFFFF      Players from level 60-130 could talk to the NPC Event Transporter then enter the map.                                |cff66FF00    Event Rewards:|cffFFFFFF                     Gem, Crystal, Holy Box, E-Gold, potion. ]==],
  },
}

----------------------------------------------------------------
-- Utility: add items to UI lists (mirrors the stock behavior)
----------------------------------------------------------------

local function add_to_daylist(ev)
  dcur_index = dcur_index + 1
  daylist_cofig[dcur_index] = ev
  local item = uiapi:AddItem("T_ListItem", day_list)
  local t  = uiapi:AddText("T_ListItemText",  item)
  local t1 = uiapi:AddText("T_ListItemText1", item)
  t:SetText(ev.Time or "")
  t1:SetText(ev.Name or "")
end

local function add_to_prolist(ev)
  pcur_index = pcur_index + 1
  prolist_config[pcur_index] = ev
  local item = uiapi:AddItem("T_ListItem", pro_list)
  local t1 = uiapi:AddText("T_ListItemText2", item)
  t1:SetText(ev.Name or "")
end

local function add_to_weeklist(ev)
  wcur_index = wcur_index + 1
  weeklist_cofig[wcur_index] = ev
  local item = uiapi:AddItem("T_ListItem", week_list)
  local t  = uiapi:AddText("T_ListItemText",  item)
  local t1 = uiapi:AddText("T_ListItemText1", item)
  t:SetText(ev.Time or "")
  t1:SetText(ev.Name or "")
end

local function add_to_guidelist(ev)
  gcur_index = gcur_index + 1
  guidelist_cofig[gcur_index] = ev
  local item = uiapi:AddItem("T_ListItem", guide_list)
  local t  = uiapi:AddText("T_ListItemText",  item)
  local t1 = uiapi:AddText("T_ListItemText1", item)
  t:SetText(ev.Time or "")
  t1:SetText(ev.Name or "")
end

local function clear_all_lists()
  uiapi:ClearItem(day_list);  uiapi:ClearItem(pro_list)
  uiapi:ClearItem(week_list); uiapi:ClearItem(guide_list)
  daylist_cofig, prolist_config, weeklist_cofig, guidelist_cofig, curlist_config = {},{},{},{},{}
  dcur_index, pcur_index, wcur_index, gcur_index = -1, -1, -1, -1
  hyper_text, flags, m_index = "", -1, -1
  multi_edit:SetText("")
end

local function event_is_today(ev)
  if type(ev.Days) ~= "table" then return false end
  local today = server_weekday()
  for _,d in ipairs(ev.Days) do if d == today then return true end end
  return false
end

----------------------------------------------------------------
-- Populate lists from static data (and keep server updates compatible)
----------------------------------------------------------------
-- Count how many distinct days an event covers (Daily => 7)
local function day_count(ev)
  if ev.Daily then return 7 end
  if type(ev.Days) == "table" then
    local seen, c = {}, 0
    for _, d in ipairs(ev.Days) do
      if not seen[d] then seen[d] = true; c = c + 1 end
    end
    return c
  end
  return 0
end
local function LoadStaticEvents()
  clear_all_lists()

  -- Buffers (we'll sort before rendering)
  local weekly_buf = {}
  local today_buf  = {}

  for _, ev in ipairs(STATIC_EVENTS) do
    -- normalize optional fields
    ev.Time      = ev.Time or ""
    ev.Name      = ev.Name or ""
    ev.Link      = ev.Link or ""
    ev.Content   = ev.Content or ""
    ev.AutoName1 = ev.AutoName1 or ""; ev.AutoAddr1 = ev.AutoAddr1 or ""
    ev.AutoName2 = ev.AutoName2 or ""; ev.AutoAddr2 = ev.AutoAddr2 or ""
    ev.AutoName3 = ev.AutoName3 or ""; ev.AutoAddr3 = ev.AutoAddr3 or ""
    ev.AutoName4 = ev.AutoName4 or ""; ev.AutoAddr4 = ev.AutoAddr4 or ""

    if ev.Type == 2 then
      add_to_prolist(ev) -- Important Announcements (separate)

    elseif ev.Type == 3 then
      -- Weekly is always shown (sorted later)
      table.insert(weekly_buf, ev)
      -- If active today (server time), also buffer for Today list
      if event_is_today(ev) then table.insert(today_buf, ev) end

    elseif ev.Type == 4 then
      add_to_guidelist(ev) -- compatibility, unused now
    end
  end

  -- Sort Weekly A→Z
  table.sort(weekly_buf, function(a,b)
    return (a.Name or ""):lower() < (b.Name or ""):lower()
  end)
  for _, ev in ipairs(weekly_buf) do add_to_weeklist(ev) end

  -- Sort Today by coverage (more days first), then A→Z
  table.sort(today_buf, function(a,b)
    local ca, cb = day_count(a), day_count(b)
    if ca ~= cb then return ca > cb end
    return (a.Name or ""):lower() < (b.Name or ""):lower()
  end)
  for _, ev in ipairs(today_buf) do add_to_daylist(ev) end

  -- default selection: Pro → Today → Weekly
  if uiapi:GetListCount(pro_list) >= 1 then
    uiapi:ActiveList(0, pro_list);   curlist_config = prolist_config[0]
  elseif uiapi:GetListCount(day_list) >= 1 then
    uiapi:ActiveList(0, day_list);   curlist_config = daylist_cofig[0]
  elseif uiapi:GetListCount(week_list) >= 1 then
    uiapi:ActiveList(0, week_list);  curlist_config = weeklist_cofig[0]
  end

  if curlist_config then
    hyper_text = curlist_config.Link or ""
    multi_edit:SetText(curlist_config.Content or "")
    Event_SetAutoSeekWay()
  end

  container:Visible(true)
  container:Auto()
end

----------------------------------------------------------------
-- Stock hooks + server-push compatibility (unchanged semantics)
----------------------------------------------------------------
function Event_OnLoad()
  win         = uiapi:GetElement(481000); win:SetPosition(101,150)
  day_list    = uiapi:GetElement(481100)
  pro_list    = uiapi:GetElement(481120)
  week_list   = uiapi:GetElement(481140)
  guide_list  = uiapi:GetElement(481160)
  multi_edit  = uiapi:GetElement(481401)
  container   = uiapi:GetElement(481400)
  curTime_text= win:GetChild("CurrentDate")

  event_btn   = uiapi:GetElement(481610)
  btn_r, btn_g, btn_b, btn_a = event_btn:GetFontColor()

  clear_all_lists()
  LoadStaticEvents()

  -- Keep listening for server updates; they’ll overwrite/refresh if they arrive.
  this:RegisterEvent(EUSER_EVENT_UPDATEEVENTINFO , "UpDate_EventInfo()")
end

function Event_Init()
  clear_all_lists()
  LoadStaticEvents()
end

-- GM flags / flashing
function Event_GMFlags(flags_in)
  if flags_in == 1 then
    GMEventInfo_WinVisible()
  elseif flags_in == 2 then
    btn_flash_visible, not_click = true, true
  elseif flags_in == 3 then
    btn_flash_visible, not_click = false, true
  end
end

-- Server-driven incremental update (kept intact to remain compatible)
function UpDate_EventInfo()
  if true then return end	-- 24/11/2026: a aba usa so a lista fixa acima (igual a do servidor); o pacote 10198 nao apaga mais a lista
  local Flags,Type,Time,Name,Link,Content,AutoName1,AutoAddr1,AutoName2,AutoAddr2,AutoName3,AutoAddr3,AutoName4,AutoAddr4 =
    GameAPI:GetEventInfo()

  if Name == "" then return end

  if Type == 1 then
    if Flags == 1 or Flags == 3 then
      multi_edit:SetText(""); hyper_text=""; flags=-1; m_index=-1; dcur_index=-1
      daylist_cofig = {}; uiapi:ClearItem(day_list)
    end
    dcur_index = dcur_index + 1
    daylist_cofig[dcur_index] = { Time=Time, Name=Name, Link=Link, Content=Content,
      AutoName1=AutoName1, AutoAddr1=AutoAddr1, AutoName2=AutoName2, AutoAddr2=AutoAddr2,
      AutoName3=AutoName3, AutoAddr3=AutoAddr3, AutoName4=AutoName4, AutoAddr4=AutoAddr4 }
    local item = uiapi:AddItem("T_ListItem", day_list)
    local text  = uiapi:AddText("T_ListItemText",  item)
    local text1 = uiapi:AddText("T_ListItemText1", item)
    text:SetText(Time); text1:SetText(Name)

  elseif Type == 2 then
    if Flags == 1 or Flags == 3 then
      multi_edit:SetText(""); hyper_text=""; flags=-1; m_index=-1; pcur_index=-1
      prolist_config = {}; uiapi:ClearItem(pro_list)
    end
    pcur_index = pcur_index + 1
    prolist_config[pcur_index] = { Time=Time, Name=Name, Link=Link, Content=Content,
      AutoName1=AutoName1, AutoAddr1=AutoAddr1, AutoName2=AutoName2, AutoAddr2=AutoAddr2,
      AutoName3=AutoName3, AutoAddr3=AutoAddr3, AutoName4=AutoName4, AutoAddr4=AutoAddr4 }
    local item = uiapi:AddItem("T_ListItem", pro_list)
    local text1 = uiapi:AddText("T_ListItemText2", item)
    text1:SetText(Name)

  elseif Type == 3 then
    if Flags == 1 or Flags == 3 then
      multi_edit:SetText(""); hyper_text=""; flags=-1; m_index=-1; wcur_index=-1
      weeklist_cofig = {}; uiapi:ClearItem(week_list)
    end
    wcur_index = wcur_index + 1
    weeklist_cofig[wcur_index] = { Time=Time, Name=Name, Link=Link, Content=Content,
      AutoName1=AutoName1, AutoAddr1=AutoAddr1, AutoName2=AutoName2, AutoAddr2=AutoAddr2,
      AutoName3=AutoName3, AutoAddr3=AutoAddr3, AutoName4=AutoName4, AutoAddr4=AutoAddr4 }
    local item = uiapi:AddItem("T_ListItem", week_list)
    local text  = uiapi:AddText("T_ListItemText",  item)
    local text1 = uiapi:AddText("T_ListItemText1", item)
    text:SetText(Time); text1:SetText(Name)

  elseif Type == 4 then
    if Flags == 1 or Flags == 3 then
      multi_edit:SetText(""); hyper_text=""; flags=-1; m_index=-1; gcur_index=-1
      guidelist_cofig = {}; uiapi:ClearItem(guide_list)
    end
    gcur_index = gcur_index + 1
    guidelist_cofig[gcur_index] = { Time=Time, Name=Name, Link=Link, Content=Content,
      AutoName1=AutoName1, AutoAddr1=AutoAddr1, AutoName2=AutoName2, AutoAddr2=AutoAddr2,
      AutoName3=AutoName3, AutoAddr3=AutoAddr3, AutoName4=AutoName4, AutoAddr4=AutoAddr4 }
    local item = uiapi:AddItem("T_ListItem", guide_list)
    local text  = uiapi:AddText("T_ListItemText",  item)
    local text1 = uiapi:AddText("T_ListItemText1", item)
    text:SetText(Time); text1:SetText(Name)
  end

  -- Default focus when server pushes anything
  local cnt = uiapi:GetListCount(pro_list)
  if cnt >= 1 then
    uiapi:ActiveList(0, pro_list)
    multi_edit:SetText("")
    hyper_text = prolist_config[0].Link
    multi_edit:SetText(prolist_config[0].Content)
    curlist_config = prolist_config[0]
    Event_SetAutoSeekWay()
    uiapi:ActiveList(-1, day_list); uiapi:ActiveList(-1, week_list); uiapi:ActiveList(-1, guide_list)
    container:Auto()
  end
end

----------------------------------------------------------------
-- Selection handlers (same content on both pages)
----------------------------------------------------------------
function Event_DayList_OnSelected()
  multi_edit:SetText("")
  m_index = uiapi:GetActiveList(day_list)
  curlist_config = daylist_cofig[m_index]
  hyper_text = curlist_config.Link
  multi_edit:SetText(curlist_config.Content)
  Event_SetAutoSeekWay()
  uiapi:ActiveList(-1, pro_list); uiapi:ActiveList(-1, week_list); uiapi:ActiveList(-1, guide_list)
  container:Auto()
end

function Event_ProList_OnSelected()
  multi_edit:SetText("")
  m_index = uiapi:GetActiveList(pro_list)
  curlist_config = prolist_config[m_index]
  hyper_text = curlist_config.Link
  multi_edit:SetText(curlist_config.Content)
  Event_SetAutoSeekWay()
  uiapi:ActiveList(-1, day_list); uiapi:ActiveList(-1, week_list); uiapi:ActiveList(-1, guide_list)
  container:Auto()
end

function Event_WeekList_OnSelected()
  multi_edit:SetText("")
  m_index = uiapi:GetActiveList(week_list)
  curlist_config = weeklist_cofig[m_index]
  hyper_text = curlist_config.Link
  multi_edit:SetText(curlist_config.Content)
  Event_SetAutoSeekWay()
  uiapi:ActiveList(-1, day_list); uiapi:ActiveList(-1, pro_list); uiapi:ActiveList(-1, guide_list)
  container:Auto()
end

function Event_GuideList_OnSelected()
  multi_edit:SetText("")
  m_index = uiapi:GetActiveList(guide_list)
  curlist_config = guidelist_cofig[m_index]
  hyper_text = curlist_config.Link
  multi_edit:SetText(curlist_config.Content)
  Event_SetAutoSeekWay()
  uiapi:ActiveList(-1, day_list); uiapi:ActiveList(-1, pro_list); uiapi:ActiveList(-1, week_list)
  container:Auto()
end

----------------------------------------------------------------
-- Hyperlink & keyword autopath (unchanged)
----------------------------------------------------------------
function Event_OnTextSelect()
  local str = uiapi:GetTextSelect(multi_edit)
  for i = 1, 4, 1 do
    local name = "AutoName"..i
    if curlist_config[name] ~= "" then
      if string.find(str, curlist_config[name]) then
        local addr = ""
        if i == 1 then      addr = curlist_config["AutoAddr1"]
        elseif i == 2 then  addr = curlist_config["AutoAddr2"]
        elseif i == 3 then  addr = curlist_config["AutoAddr3"]
        elseif i == 4 then  addr = curlist_config["AutoAddr4"]
        end
        local a,b,mapid,posx,posy,amapid,aposx,aposy = string.find(addr,"(-?%d+),(-?%d+),(-?%d+),(-?%d+),(-?%d+),(-?%d+)")
        local camp = PlayerAPI:GetGameData():GetFaction()
        if camp == 0 then GameAPI:AutoSeekWay(mapid,posx,posy) else GameAPI:AutoSeekWay(amapid,aposx,aposy) end
        return
      end
    end
  end
end

function Event_SetAutoSeekWay()
  uiapi:ClearTextSelectKey(multi_edit)
  for i = 1, 4, 1 do
    local name = "AutoName"..i
    if curlist_config[name] ~= "" then
      uiapi:SetTextSelectColor(i-1, "HelpSystem_Color1", multi_edit)
      uiapi:SetTextSelectKey(i-1, curlist_config[name], multi_edit)
    end
  end
end

function PlayerLinkBtn_OnClick()
  if hyper_text == nil or hyper_text == "" then return end	-- ETAPA 142
  uiapi:HyperLink(hyper_text)
end

----------------------------------------------------------------
-- Button / flashing / date label (kept)
----------------------------------------------------------------
function EventInfo_OnClick() GMEventInfo_OnClick() end

function EventBtn_OnClick()
  win = uiapi:GetElement("ActivityWin")
  win:Visible(not win:IsVisible())
  if win:IsVisible() then
    win:SetPosition(101,150); win:Top()
    if btn_flash_visible then not_click = false end
  end
end

function EventBtn_Update()
  if btn_flash_visible and not_click then
    count = count + 1
    if count % 30 == 0 then
      this:SetFontColor(255, 0, 0, btn_a)
    elseif count % 15 == 0 then
      this:SetFontColor(0, 255, 0, btn_a)
    end
  else
    this:SetFontColor(btn_r, btn_g, btn_b, btn_a)
    count = 0
  end
end

-- Optional label (if used in your XML)
function Event_Time(text, day)
  -- Set your own localized weekday text if needed.
  if curTime_text then curTime_text:SetText(text or "") end  -- ETAPA 148b: o jogo fechava quando o servidor mandava a hora (CurrentDate nao existe nesta janela)
end
