﻿local win = UIAPI:GetElement("FirstWin");
-- ETAPA 180 (Claude, 23/11/2026): Callidora - missoes do dia do Atlantis Portal (SYS 113; servidor Atlantis180.inl).
-- Antes era o NPC de Halloween (nao usado no servidor).
-- status = 1000000000 + dias_semana*100000000 + sequencia*10000000 + recebidas*1000000 + q3*100000 + q2*1000 + q1
ATL180_Q1 = 50
ATL180_Q2 = 3
ATL180_SEQPCT = 5
ATL180_SEMDIAS = 5

function NpcFunHallo_SetUI(Type,Index)
	FirstWin_ButtonA1:Visible(true);
	FirstWin_ButtonA2:Visible(true);
	win:Visible(true);
end

local function Atl180_Dig(v, div, base)
	return math.floor(math.mod(math.floor(v / div), base))
end

local function Atl180_Marca(feito, bit, rec)
	if math.mod(math.floor(rec / bit), 2) == 1 then
		return " |cff00ff00(received)|cFFFFFFFF"
	elseif feito then
		return " |cffFFD700(done! claim below)|cFFFFFFFF"
	end
	return ""
end

function NpcFunHallo_SetText(Type,Index,BtnID,SubID)
	if Index == 1 then
		if SubID >= 1000000000 then
			local q1 = Atl180_Dig(SubID, 1, 1000)
			local q2 = Atl180_Dig(SubID, 1000, 100)
			local q3 = Atl180_Dig(SubID, 100000, 10)
			local rec = Atl180_Dig(SubID, 1000000, 10)
			local seq = Atl180_Dig(SubID, 10000000, 10)
			local sem = Atl180_Dig(SubID, 100000000, 10)
			local t = "|cffF14187Welcome to Atlantis! These are your quests for today (they reset at midnight):|cFFFFFFFF\n"
			t = t .. "    1. Defeat " .. ATL180_Q1 .. " monsters: " .. math.min(q1, ATL180_Q1) .. "/" .. ATL180_Q1 .. Atl180_Marca(q1 >= ATL180_Q1, 1, rec) .. "  - reward: Silver\n"
			t = t .. "    2. Defeat " .. ATL180_Q2 .. " Tide Champions: " .. math.min(q2, ATL180_Q2) .. "/" .. ATL180_Q2 .. Atl180_Marca(q2 >= ATL180_Q2, 2, rec) .. "  - reward: Honor\n"
			t = t .. "    3. Defeat Dinna the Sea Guard: " .. q3 .. "/1" .. Atl180_Marca(q3 >= 1, 4, rec) .. "  - reward: HardPoints\n"
			t = t .. "|cffF14187Streak:|cFFFFFFFF " .. seq .. " day(s) in a row (+" .. ((seq - 1) * ATL180_SEQPCT) .. "% rewards)\n"
			t = t .. "|cffF14187Weekly chest:|cFFFFFFFF " .. sem .. "/" .. ATL180_SEMDIAS .. " days completed"
			FirstWin_Text1:SetText(t);
			FirstWin_Text1:Visible(true);
		elseif SubID == 2 then
			local Button = win:GetChild("FirstWin_Button" .. BtnID);
			Button:SetPosition(25,200);
			Button:SetText("* Claim rewards");
			Button:Visible(true);
		elseif SubID == 3 then
			local Button = win:GetChild("FirstWin_Button" .. BtnID);
			Button:SetPosition(25,220);
			Button:SetText("* How Atlantis works");
			Button:Visible(true);
		end;
	elseif Index == 2 then
		if SubID == 4 then
			FirstWin_Text1:SetText("|cffF14187Rewards delivered!|cFFFFFFFF\nThe amounts you received are shown in the chat.\nCome back tomorrow to keep your streak!");
		elseif SubID == 5 then
			FirstWin_Text1:SetText("You have no new completed quest today.\nCome back when you finish one!");
		elseif SubID == 6 then
			FirstWin_Text1:SetText("|cffF14187Wave 1 (until minute 10):|cFFFFFFFF defeat 50 monsters in the middle of the map. They come 10 at a time.\n|cffF14187Wave 2 (until minute 20):|cFFFFFFFF defeat the 3 Tide Champions. They are stronger and worth more points.\n|cffF14187Wave 3:|cFFFFFFFF Dinna the Sea Guard appears with 2 elites. Defeat Dinna to complete Atlantis.\nCleared a wave early? The next one comes in 3 seconds. Time is up? The rest disappears and the next wave starts.\n|cffF14187Streak:|cFFFFFFFF claim the 3 quests on consecutive days to earn up to +30%. Miss a day and it starts over.\n|cffF14187Weekly chest:|cFFFFFFFF complete the quests on 5 days of the week (Monday to Sunday).");
		end;
		FirstWin_Text1:Visible(true);
		NPCFUN:EndMessage(true);
	end;
end
