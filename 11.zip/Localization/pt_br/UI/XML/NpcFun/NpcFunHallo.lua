﻿local win = UIAPI:GetElement("FirstWin");
-- ETAPA 180 (Claude, 23/11/2026): Callidora - missoes do dia do Atlantis Portal (SYS 113; servidor Atlantis180.inl).
-- Antes era o NPC de Halloween (nao usado no servidor).
-- status = 1000000000 + dias_semana*100000000 + sequencia*10000000 + recebidas*1000000 + q3*100000 + q2*1000 + q1
ATL180_Q1 = 50
ATL180_Q2 = 3
ATL180_SEQPCT = 5
ATL180_SEMDIAS = 5

function NpcFunHallo_SetUI(Type,Index)
	FirstWin_ButtonA1:Visible(true);
	FirstWin_ButtonA2:Visible(true);
	win:Visible(true);
end

local function Atl180_Dig(v, div, base)
	return math.floor(math.mod(math.floor(v / div), base))
end

local function Atl180_Marca(feito, bit, rec)
	if math.mod(math.floor(rec / bit), 2) == 1 then
		return " |cff00ff00(recebido)|cFFFFFFFF"
	elseif feito then
		return " |cffFFD700(pronto! receba abaixo)|cFFFFFFFF"
	end
	return ""
end

function NpcFunHallo_SetText(Type,Index,BtnID,SubID)
	if Index == 1 then
		if SubID >= 1000000000 then
			local q1 = Atl180_Dig(SubID, 1, 1000)
			local q2 = Atl180_Dig(SubID, 1000, 100)
			local q3 = Atl180_Dig(SubID, 100000, 10)
			local rec = Atl180_Dig(SubID, 1000000, 10)
			local seq = Atl180_Dig(SubID, 10000000, 10)
			local sem = Atl180_Dig(SubID, 100000000, 10)
			local t = "|cffF14187Bem-vindo ao Atlantis! Estas são as suas missões de hoje (zeram à meia-noite):|cFFFFFFFF\n"
			t = t .. "    1. Derrotar " .. ATL180_Q1 .. " monstros: " .. math.min(q1, ATL180_Q1) .. "/" .. ATL180_Q1 .. Atl180_Marca(q1 >= ATL180_Q1, 1, rec) .. "  - prêmio: Silver\n"
			t = t .. "    2. Derrotar " .. ATL180_Q2 .. " Campeões da Maré: " .. math.min(q2, ATL180_Q2) .. "/" .. ATL180_Q2 .. Atl180_Marca(q2 >= ATL180_Q2, 2, rec) .. "  - prêmio: Honra\n"
			t = t .. "    3. Derrotar Dinna the Sea Guard: " .. q3 .. "/1" .. Atl180_Marca(q3 >= 1, 4, rec) .. "  - prêmio: HardPoints\n"
			t = t .. "|cffF14187Sequência:|cFFFFFFFF " .. seq .. " dia(s) seguidos (+" .. ((seq - 1) * ATL180_SEQPCT) .. "% nos prêmios)\n"
			t = t .. "|cffF14187Baú da semana:|cFFFFFFFF " .. sem .. "/" .. ATL180_SEMDIAS .. " dias completos"
			FirstWin_Text1:SetText(t);
			FirstWin_Text1:Visible(true);
		elseif SubID == 2 then
			local Button = win:GetChild("FirstWin_Button" .. BtnID);
			Button:SetPosition(25,200);
			Button:SetText("* Receber prêmios");
			Button:Visible(true);
		elseif SubID == 3 then
			local Button = win:GetChild("FirstWin_Button" .. BtnID);
			Button:SetPosition(25,220);
			Button:SetText("* Como funciona o Atlantis");
			Button:Visible(true);
		end;
	elseif Index == 2 then
		if SubID == 4 then
			FirstWin_Text1:SetText("|cffF14187Prêmios entregues!|cFFFFFFFF\nOs valores que você ganhou aparecem no chat.\nVolte amanhã para não perder a sua sequência de dias!");
		elseif SubID == 5 then
			FirstWin_Text1:SetText("Você ainda não completou nenhuma missão nova hoje.\nVolte quando terminar uma delas!");
		elseif SubID == 6 then
			FirstWin_Text1:SetText("|cffF14187Onda 1 (até o minuto 10):|cFFFFFFFF derrote 50 monstros no meio do mapa. Eles vêm 10 de cada vez.\n|cffF14187Onda 2 (até o minuto 20):|cFFFFFFFF derrote os 3 Campeões da Maré. Eles são mais fortes e valem mais pontos.\n|cffF14187Onda 3:|cFFFFFFFF Dinna the Sea Guard aparece com 2 elites. Derrote a Dinna para completar o Atlantis.\nLimpou a onda antes do tempo? A próxima vem em 3 segundos. Acabou o tempo? O que sobrou some e a próxima onda começa.\n|cffF14187Sequência:|cFFFFFFFF receba as 3 missões em dias seguidos para ganhar até +30%. Se faltar um dia, ela volta para o começo.\n|cffF14187Baú da semana:|cFFFFFFFF complete as missões em 5 dias da semana (segunda a domingo).");
		end;
		FirstWin_Text1:Visible(true);
		NPCFUN:EndMessage(true);
	end;
end
