﻿--MinMap相关的函数 tavia
--2009.07.16
local uiapi=UIAPI
local win = nil
local timeText = nil;

function MinMapSetServerTime(str)
	if win == nil then
		win = uiapi:GetElement("MapWinBack");
	end
	if win == nil then return end  -- ETAPA 148b: protecao (nao fechar o jogo)
	if timeText == nil then
		timeText = win:GetChild("TimeText");
	end
	if timeText then timeText:SetText(str); end

end

