﻿--tavia，用于lua的2次确认操作。

LUA_MESSAGEBOX_ROOKIE  = 1 --新手引导
LUA_MESSAGEBOX_NULL  = 2   --待续

local win = nil
local text = nil
local m_type = 0
local uiapi = UIAPI

--初始化
function LuaMessageBox_Init()
	win = uiapi:GetElement("LuaMessageBoxWin");
	text = win:GetChild("Text")

	win:UpdateRenderBuffer();

end
--设置确认框的内容
function LuaMessageBox_Visible(str,type)
	if not win:IsVisible() then
		text:SetText(str)
		m_type = type
		win:Visible(true)
		win:Top()
	end

end
--判断确认框是否打开
function LuaMessageBox_GetVisible()
	return win:IsVisible()
end
--确定按钮的操作
function LuaMessageBox_OK()
	if GD_IdiomaAberto then
		GD_IdiomaAberto = false
		pcall(function()
			local w = UIAPI:GetElement("LuaMessageBoxWin")
			w:GetChild("CloseBtn"):Visible(true)
			local ok = w:GetChild("OKBtn")
			ok:SetText(C_X2_3)
			local x, y = ok:GetPosition()
			ok:SetPosition(x - 60, y)
		end)
	end
	if m_type == LUA_MESSAGEBOX_ROOKIE then
		RookieGuide_OK()

	elseif  m_type == LUA_MESSAGEBOX_NULL then
		--待续
	end

	win:Visible(false)
end
--取消按钮的操作
function LuaMessageBox_Cancel()
	win:Visible(false)

end





-- GodsDomain (15/11): troca o idioma do jogo (botao na janela de opcoes). Grava o config.ini e pede para reabrir.
function GD_TrocarIdioma()
	local f = io.open("config.ini", "rb")
	if not f then return end
	local t = f:read("*a")
	f:close()
	local novo = "pt_br"
	local msg = "Idioma: Português\nReinicie o jogo."
	if string.find(t, "Locals=pt_br", 1, true) then
		novo = "en_us"
		msg = "Language: English\nRestart the game."
	end
	local t2, n = string.gsub(t, "Locals=[%w_]+", "Locals=" .. novo, 1)
	if n == 0 then t2 = string.gsub(t, "%[SYSTEM%]", "[SYSTEM]\r\nLocals=" .. novo, 1) end
	f = io.open("config.ini", "wb")
	if not f then return end
	f:write(t2)
	f:close()
	pcall(LuaMessageBox_Visible, msg, LUA_MESSAGEBOX_NULL)
	-- so um botao OK no meio (volta ao normal quando fechar)
	pcall(function()
		local w = UIAPI:GetElement("LuaMessageBoxWin")
		w:GetChild("CloseBtn"):Visible(false)
		local ok = w:GetChild("OKBtn")
		ok:SetText("OK")
		local x, y = ok:GetPosition()
		ok:SetPosition(x + 60, y)
		GD_IdiomaAberto = true
	end)
end
