﻿-- this is Text config
-- edit by LiDeXun. any questions find me!

UITEXT_LOGIN = "ENTRAR"


-- AltarSuspendConfig.lua
ASC_L0_1 = "Apollo"
ASC_L0_2 = "HP Máx."
ASC_L0_3 = "MP Máx."
ASC_L0_4 = "Demeter"
ASC_L0_5 = "Regen. HP"
ASC_L0_6 = "Absorção"
ASC_L0_7 = "Hermes"
ASC_L0_8 = "Regen. MP"
ASC_L0_9 = "Hephaestus"
ASC_L0_10 = "Ataque"
ASC_L0_11 = "Acerto"
ASC_L0_12 = "Hades"
ASC_L0_13 = "Ataque Mág."
ASC_L0_15 = "Dionysus"
ASC_L0_16 = "Defesa"
ASC_L0_17 = "Defesa Mág."
ASC_L0_18 = "Aphrodite"
ASC_L0_19 = "Dano Mágico"
ASC_L0_20 = "Absorção"
ASC_L0_21 = "Hestia"
ASC_L0_22 = "Esquiva"
ASC_L0_23 = "Poseidon"
ASC_L0_24 = "Artemis"



-- AltarSuspendProc.lua
ASP_L0_1 = "Nível:"
ASP_L0_2 = "Próximo"
ASP_L0_3 = "Precisa de fundos:"
ASP_L0_4 = ",Gold:"
ASP_L0_5 = "O nível chegou ao máximo!"
ASP_L0_6 = "Seu nível de oferenda:"
ASP_L0_7 = "Contrib. p/ o próximo:"
ASP_L0_8 = "Nível máximo alcançado"


-- AutoFight.lua

-- AutoFight.xml

AF_X0_1 = "Usar skills"
AF_X0_2 = "Atacar sozinho"
AF_X0_3 = "Recuperação:"
AF_X0_4 = "HP abaixo"
AF_X0_5 = "0% = usar poção"
AF_X0_6 = "MP abaixo"
AF_X0_7 = "0% = usar poção"
AF_X0_8 = "Voltar à cidade sozinho:"
AF_X0_9 = "Poções de HP acima de"
AF_X0_10 = "Poções de MP acima de"
AF_X0_11 = "Coloque a skill ou pergaminho de portal:"
AF_X0_12 = "Sistema AFK GodsDomain"
AF_X0_13 = "Salvar"
AF_X0_14 = "Iniciar"
AF_X0_15 = "1. Marque 'Usar skills' e arraste as skills para os espaços vazios. Clique em 'Salvar' e 'Iniciar'."
AF_X0_16 = "2. Arraste poções ou skills para os espaços de Recuperação."
AF_X0_17 = "3. Salve e aperte 'F12' para começar o AFK."
AF_X0_18 = "Renascer"
AF_X0_19 = "Renascer sozinho"
AF_X0_20 = "Renascer no AFK:"
AF_X0_21 = " "
AF_X0_22 = "Reviver após      min. (0 = desligado)"
AF_X0_23 = "Config. de renascer"
AF_X0_24 = "vezes em"
AF_X0_25 = "min, depois"
AF_X0_26 = "min para renascer de novo."
AF_X0_27 = "mortes depois, para de renascer."
AF_X0_28 = "1. Marque 'Renascer sozinho'."
AF_X0_29 = "2. Cada renascimento custa 10 Gold."
AF_X0_30 = "3. Desconectou = o AFK para."
AF_X0_31 = "Pet"
AF_X0_32 = "Alimentar"
AF_X0_33 = "alimentar sozinho com"
AF_X0_34 = "1. Marque a opção 'Alimentar'."
AF_X0_35 = "2. Arraste a comida para o quadro acima."
AF_X0_36 = "Quando a saciedade do pet ficar abaixo de"
AF_X0_37 = "AFK"
AF_X0_38 = "Coletar"
AF_X0_39 = "Coleta automática: fica ligada por x hora(s)."
AF_X0_40 = "Config. de coleta:"
AF_X0_41 = "Melhoria"
AF_X0_42 = "Equipamento"
AF_X0_43 = "Materiais"
AF_X0_44 = "Pergaminhos"
AF_X0_45 = "Livros"
AF_X0_46 = "Poções"
AF_X0_47 = "Para pets"
AF_X0_48 = "Outros"
AF_X0_49 = "Sobre a coleta automática"
AF_X0_50 = "1. Para usar a coleta automática, use um Plump Wheat ou um Golden Leaf."
AF_X0_51 = "2. Escolha o filtro."
AF_X0_52 = "Marque os tipos de item que serão pegos sozinhos."

-- AutoSeekWayUI.xml

ASW_X0_1 = "Buscar"
ASW_X0_2 = "Andando"

-- ButtonClick.lua
BC_X0_1 = "Hora do servidor"
BC_X0_2 = "Masculino"
BC_X0_3 = "Feminino"

-- BattleUI.xml

B_X0_1 = "Sair"
B_X0_2 = "Entrar"
B_X0_3 = "Desistir"
B_X0_4 = "Encerrar"
B_X0_5 = "Ver grupo"
B_X0_6 = "Aguardando"
B_X0_7 = "Na fila"
B_X0_8 = "º"
B_X0_9 = ""
B_X0_10 = "A porta abriu"
B_X0_11 = "Confirmando:"
B_X0_12 = "s "
B_X0_13 = "Tempo"
B_X0_14 = "Pontos"
B_X0_15 = "Nosso time"
B_X0_16 = "min"
B_X0_17 = "Pediram p/ encerrar"
B_X0_18 = "Vote! (Prêmio "
B_X0_19 = " pelo progresso.)"
B_X0_20 = "Tempo"
B_X0_21 = "Sim"
B_X0_22 = "Não"
B_X0_23 = "Te convidaram!"
B_X0_24 = "Confirmando:"
B_X0_25 = "Entrar"
B_X0_26 = "Desistir"
B_X0_27 = "Instância"
B_X0_28 = "Reinicia em"
B_X0_29 = "Sair"


-- ChatUI.xml

C_X0_1 = "Geral"
C_X0_2 = "Facção"
C_X0_3 = "Grupo"
C_X0_4 = "Guilda"
C_X0_5 = "PM"
C_X0_6 = "Geral"
C_X0_7 = "Mundo"
C_X0_8 = "Grupo"
C_X0_9 = "Guilda"
C_X0_10 = "PM"
C_X0_11 = "Info"
C_X0_12 = "Grupo"
C_X0_13 = "Trocar"
C_X0_14 = "Amigo"
C_X0_15 = "PM"
C_X0_16 = "Bloquear"
C_X0_17 = "Convidar"
C_X0_18 = "Facção"
C_X0_19 = "Convite"
C_X0_20 = "Comandos do chat:"
C_X0_21 = "1. /N  chat geral"
C_X0_22 = "2. /P  chat da facção"
C_X0_23 = "3. /G  chat da guilda"
C_X0_24 = "4. /T  chat do grupo"
C_X0_25 = "Histórico:"
C_X0_26 = "Use ↑ e ↓ para ver as últimas dez mensagens"
C_X0_27 = "Cuidado com as informações que aparecem no chat."
C_X0_28 = "~Enter para falar~"
C_X0_29 = "Geral"
C_X0_30 = "Ocultar"
C_X0_31 = "Mostrar"
-- ChatWndUI.xml

CW_X0_1 = "Conversando com XXX"
CW_X0_2 = "Enviar"
CW_X0_3 = "Emoções"
CW_X0_4 = "Responder"

-- Consortia.xml

C_X1_1 = "Guilda"
C_X1_2 = "Ver offline"
C_X1_3 = "Nome"
C_X1_4 = "Classe"
C_X1_5 = "Nv."
C_X1_6 = "Contrib."
C_X1_7 = "Lema:"
C_X1_8 = "Este é o lema da minha guilda!"
C_X1_9 = "Nível:"
C_X1_10 = "Máx. membros:"
C_X1_11 = "Silver:"
C_X1_12 = "Gold:"
C_X1_13 = "Altar:"
C_X1_14 = "Detalhes"
C_X1_15 = "Expulsar"
C_X1_16 = "Promover"
C_X1_17 = "Rebaixar"
C_X1_18 = "PM"
C_X1_19 = "Grupo"
C_X1_20 = "Convidar"
C_X1_21 = "Editar"
C_X1_22 = "Passar líder"
C_X1_23 = "Sair"
C_X1_24 = "Mall"
C_X1_25 = "Gold:"
C_X1_26 = "Comprar"
C_X1_27 = "Recarregar"
C_X1_28 = "Aliado"
C_X1_29 = "Nome da guilda"
C_X1_30 = "OK"
C_X1_31 = "Cancelar"
C_X1_32 = "Lema"
C_X1_33 = "Objetivo"
C_X1_34 = "Cargo"
C_X1_35 = "Silver"
C_X1_36 = "Gold"
C_X1_37 = "Info"
C_X1_38 = "Logo da guilda ainda não disponível. "
C_X1_39 = "Brasão"
C_X1_40 = "Líder:"
C_X1_41 = "Vice:"
C_X1_42 = "Prédios"
C_X1_43 = "Prédio"
C_X1_44 = "Descrição"
C_X1_45 = "Logo"
C_X1_46 = "Lista"
C_X1_47 = "Nome da guilda"
C_X1_48 = "Nível"
C_X1_49 = "Força"
C_X1_50 = "Membros"
C_X1_51 = "Prédio"
C_X1_52 = "Entrar"
C_X1_53 = "Pedir"
C_X1_54 = "Recusar o pedido?"
C_X1_55 = "Facção"
C_X1_56 = "Estrutura"
C_X1_57 = "Sobre"
C_X1_58 = "Pode doar"
C_X1_59 = "Doado hoje"
C_X1_60 = "Doar"
C_X1_61 = "  Digite a quantia               que quer doar."
C_X1_62 = "1 Copper Ore = 1 ponto de contribuição."
C_X1_63 = "Pts. contrib."


-- CounterUI.xml

C_X2_1 = "MÁX"
C_X2_2 = "Voltar"
C_X2_3 = "Sim"
C_X2_4 = "Não"


--Constellation.xml

CON_X0_1 = "Detalhes"
CON_X0_2 = "Grau:"
CON_X0_3 = "Energia guardada:"
CON_X0_4 = "EXP , EXP de Talento"
CON_X0_5 = "Melhorar"
CON_X0_6 = "Liberar"
CON_X0_7 = "Energia"
CON_X0_8 = "Gold"
CON_X0_9 = "Fechado"
CON_X0_10 = "Treinar"
CON_X0_11 = "Energia: "
CON_X0_12 = "Energia nec.:"
CON_X0_13 = "Nível necessário:"
CON_X0_14 = "Melhorar"
CON_X0_15 = "EXP acum."
CON_X0_16 = "Você ganha bastante EXP matando monstros, fazendo missões e usando EXP Stones. A EXP acumulada é um bônus que aumenta quando o Zodíaco sobe de grau ou pagando Gold, deixando o efeito maior."
CON_X0_17 = "|cFFDCC883 Efeito |cFFFFFFFF"
CON_X0_18 = "EXP acumulada: "
CON_X0_19 = "EXP de Talento acumulada: "
CON_X0_20 = "|cFFDCC883 Próximo grau |cFFFFFFFF"
CON_X0_21 = "|cFFDCC883 Para subir: |cFFFFFFFF"
CON_X0_22 = "Energia do Zodíaco: "
CON_X0_23 = "ou Gold: "
CON_X0_24 = "EXP acum.: "
CON_X0_25 = "Talento acum.: "
CON_X0_26 = "Subir efeito"
CON_X0_27 = "Treino"
CON_X0_28 = "Treinar ATQ"
CON_X0_29 = "Melhorar ATQ"
CON_X0_30 = "Treinar DEF"
CON_X0_31 = "Melhorar DEF"
CON_X0_32 = "Escolher"
CON_X0_33 = "Treinar e melhorar skills de ataque aumenta o poder de ataque. Quanto mais forte, mais MP a skill gasta. Treinar e melhorar skills de defesa diminui o dano que o inimigo causa em você."
CON_X0_34 = "Máx. de EXP acumulada:"
CON_X0_35 = "Máx. de EXP de Talento acumulada:"
CON_X0_36 = "Requisitos do treino de skill|cFFFFFFFF"
CON_X0_37 = "Lvl   ENERGY   TP   \t\t Lvl   ENERGY   TP   \n|cFFDCC883----------------------------------------\n|cffCD7F322|cFFFFFFFF  \t\t5        7\t\t\t\t\t |cffCD7F3217|cFFFFFFFF\t\t\t2382\t\t 2186\n|cffCD7F323|cFFFFFFFF  \t\t12       15\t\t\t   |cffCD7F3218|cFFFFFFFF\t\t\t2977\t\t 2583\n|cffCD7F324|cFFFFFFFF  \t\t17\t\t\t\t\t25\t\t\t\t  |cffCD7F3219|cFFFFFFFF\t\t\t3575\t\t\t2982\n|cffCD7F325|cFFFFFFFF  \t\t25       32\t\t\t   |cffCD7F3220|cFFFFFFFF\t\t 4170\t\t 3381\n|cffCD7F326|cFFFFFFFF  \t\t30\t\t\t\t\t40\t\t\t   |cffCD7F3221|cFFFFFFFF\t\t\t5366\t\t\t4040\n|cffCD7F327|cFFFFFFFF  \t\t60 \t\t\t\t263\t\t\t\t |cffCD7F3222|cFFFFFFFF\t\t\t5996\t\t\t4470\n|cffCD7F328|cFFFFFFFF  \t\t119\t\t\t\t362\t\t\t\t |cffCD7F3223|cFFFFFFFF\t\t\t6666\t\t\t4950\n|cffCD7F329|cFFFFFFFF  \t\t179\t\t\t\t523\t\t\t\t |cffCD7F3224|cFFFFFFFF\t\t\t7386\t\t\t5510\n|cffCD7F3210|cFFFFFFFF \t\t238\t\t\t\t682\t\t\t\t |cffCD7F3225|cFFFFFFFF\t\t\t8166\t\t\t6190\n|cffCD7F3211|cFFFFFFFF\t\t\t298\t\t\t\t920\t\t\t  |cffCD7F3226|cFFFFFFFF\t\t\t9016\t\t\t7040\n|cffCD7F3212|cFFFFFFFF\t\t\t595\t\t\t\t955\t\t\t\t |cffCD7F3227|cFFFFFFFF\t\t\t9946\t\t\t8120\n|cffCD7F3213|cFFFFFFFF\t\t\t893\t\t\t\t1196\t\t\t\t|cffCD7F3228|cFFFFFFFF\t\t\t10966\t\t9500\n|cffCD7F3214|cFFFFFFFF\t\t\t1191\t\t\t1434\t\t\t\t|cffCD7F3229|cFFFFFFFF\t\t\t12086\t\t11300\n|cffCD7F3215|cFFFFFFFF\t\t\t1489\t\t\t1672\t\t\t\t|cffCD7F3230|cFFFFFFFF\t\t\t13316\t  13060\n|cffCD7F3216|cFFFFFFFF\t\t\t1789\t\t\t1786\t\t\t\t|cffCD7F3231|cFFFFFFFF\t\t\t\t|cffCD7F32N\A|cFFFFFFFF\t\t\t\t |cffCD7F32N\A|cFFFFFFFF"
CON_X0_38 = "Nv. nec."


--Constellation.lua

CON_L0_1 = "Ganhar energia:"
CON_L0_2 = "Gema melhorada! Gold gasto:"
CON_L0_3 = "Gema melhorada! Energia gasta:"
CON_L0_4 = "|cff00CCFFO Zodíaco subiu|cffffffff |cff00CCFFpara o|cffffffff"
CON_L0_5 = " |cff00CCFFgrau|cffffffff"
CON_L0_6 = "Ganhou energia offline"
CON_L0_7 = "Ganhou EXP:"
CON_L0_8 = "Ganhou EXP de Talento:"
CON_L0_9 = "EXP acumulada:"
CON_L0_10 = "EXP de Talento acumulada:"
CON_L0_11 = "EXP acumulada:"
CON_L0_12 = "EXP de Talento acumulada:"
CON_L0_13 = "Esta função ainda não foi liberada."
CON_L0_14 = "Grau:"
CON_L0_15 = "EXP de Talento acumulada:"
CON_L0_16 = "Energia necessária:"
CON_L0_17 = "Gold necessário:"
CON_L0_18 = "Nível do personagem:"
CON_L0_19 = "Zodíaco"
CON_L0_20 = "Hoje é seu dia de sorte! +5% no efeito das gemas por 24 horas."
CON_L0_21 = "EXP acumulada:"
CON_L0_22 = "ou"
CON_L0_23 = "Áries"
CON_L0_24 = "Touro"
CON_L0_25 = "Gêmeos"
CON_L0_26 = "Câncer"
CON_L0_27 = "Leão"
CON_L0_28 = "Virgem"
CON_L0_29 = "Libra"
CON_L0_30 = "Escorpião"
CON_L0_31 = "Sagitário"
CON_L0_32 = "Capricórnio"
CON_L0_33 = "Aquário"
CON_L0_34 = "Peixes"
CON_L0_35 = "Melhoria de skill ativada"
CON_L0_36 = "Espaço ativado"
CON_L0_37 = "Espaço melhorado"
CON_L0_38 = "Fechado"
CON_L0_39 = "Próximo"
CON_L0_40 = "   Zodíaco no nível MÁXIMO"
CON_L0_41 = "EXP acumulada no MÁXIMO."
CON_L0_42 = "Não precisa melhorar"

-- CretitExchangeUI.xml

-- DesignateUI.xml

D_X0_1 = "Trocar"
D_X0_2 = "Esconder"
D_X0_3 = "Missão"
D_X0_4 = "Iron Warrior"
D_X0_5 = "Descrição"

-- DialUI.xml

D_X1_1 = "Começar"
D_X1_2 = "Sortear +"
D_X1_3 = "Pegar"
D_X1_4 = "Reabrir"


-- EquipForge.xml

EF_X0_1 = "Chance:"
EF_X0_2 = "Sem perda"
EF_X0_3 = "Detalhes"
EF_X0_4 = "1.Rubis sobem o Nível."
EF_X0_5 = "2.Safiras sobem a Qualidade (atributos brancos)."
EF_X0_6 = "3.Esmeraldas sobem o Grau (atributos verdes)."
EF_X0_7 = "4.Se falhar, o equipamento não estraga."
EF_X0_8 = "5.Cristais aumentam a chance."
EF_X0_9 = "1.Rubis, Safiras, Esmeraldas e Spring Water podem ser combinados."
EF_X0_10 = "2.6 gemas de nível baixo viram 1 gema de nível acima."
EF_X0_11 = "3.6 Spring Water viram 1 Juice of Rebirth."
EF_X0_12 = "4.Cristais não podem ser combinados."
EF_X0_13 = "  Botão 'Encher'"
EF_X0_14 = "5.Precisa de gemas da mesma cor e nível."
EF_X0_15 = "1.Combinar com sucesso sorteia de novo os atributos verdes do equipamento principal."
EF_X0_16 = "2.Depois de combinar, os equipamentos de apoio somem."
EF_X0_17 = "3.Os equipamentos de apoio não podem ter mais de 5 níveis abaixo do principal."
EF_X0_18 = "  até 5 níveis abaixo do 1º."
EF_X0_19 = "4.Sorteia atributos novos."
EF_X0_20 = "5.Equip. melhor, atributo melhor."
EF_X0_21 = "Coloque o equipamento principal"
EF_X0_22 = "Coloque as gemas"
EF_X0_23 = "Coloque a Lucky Coin"
EF_X0_24 = "Coloque cristais(|cffD5912BMáx. 25|cffffffff)"
EF_X0_25 = "Coloque o equipamento principal"
EF_X0_26 = "Coloque o equip. de apoio"
EF_X0_27 = "Coloque os materiais para combinar."
EF_X0_28 = "Precisa:"
EF_X0_29 = "S"
EF_X0_30 = "Forja"
EF_X0_31 = "Gemas"
EF_X0_32 = "Combinar"
EF_X0_33 = "Começar"
EF_X0_34 = "Começar"
EF_X0_35 = "Encher"
EF_X0_36 = "Cancelar"
EF_X0_37 = "6.Até 25 cristais."
EF_X0_38 = "1.Uma Ametista nível 3 transforma o equipamento em outro do mesmo tipo."
EF_X0_39 = "2.Qualidade, grau e atributos verdes não mudam."
EF_X0_40 = "3.Clique em Prévia para ver e escolher o equipamento novo."
EF_X0_41 = "4.A transformação sempre dá certo (100%)."
EF_X0_42 = "Transf."
EF_X0_43 = "Coloque o equipamento escolhido"
EF_X0_44 = "Prévia"
EF_X0_45 = "Transformar"
EF_X0_46 = "Coloque o equipamento:"
EF_X0_47 = "Coloque a gema:"
EF_X0_48 = "Cristais aumentam a chance (máx. 25):"
EF_X0_49 = "Equipamento novo:"
EF_X0_50 = "Coloque 6 gemas abaixo:"
EF_X0_51 = "Gema nova:"
EF_X0_52 = "Equipamento principal abaixo:"
EF_X0_53 = "3 equipamentos de apoio abaixo:"
EF_X0_54 = "Equipamento novo:"
EF_X0_55 = "Coloque o equipamento:"
EF_X0_56 = "Coloque a Ametista nível 3:"
EF_X0_57 = "Clique para escolher o equipamento novo:"
EF_X0_58 = "Prévia:"
EF_X0_59 = "Equipamento novo:"

--Event.xml

E_X0_1= "Eventos da semana"
E_X0_2= "Horário"
E_X0_3= "Evento"
E_X0_4= "Aviso importante"
E_X0_5= "Conteúdo"
E_X0_6= "Ver tudo"
E_X0_7= "Evento"
E_X0_8= "Publicado em"
E_X0_9= "Título"

--GMEventEdit.xml

GE_X0_1= "Eventos da semana"
GE_X0_2= "Horário"
GE_X0_3= "Evento"
GE_X0_4= "Link"
GE_X0_5= "Aviso importante"
GE_X0_6= "Conteúdo"
GE_X0_7= "Enviar"
GE_X0_8= "Carregando"
GE_X0_9= "Limpar"
GE_X0_10= "Publicado em"
GE_X0_11= "Título"


-- GodwardMapUI.xml

GM_X0_1 = "Mundo"
GM_X0_2 = "Config."

-- HelpSystem.xml

HS_X0_1 = "Ajuda"
HS_X0_2 = "Iniciante"
HS_X0_3 = "Atributos"
HS_X0_4 = "Missões"
HS_X0_5 = "Skills"
HS_X0_6 = "  Warrior"
HS_X0_7 = "  Champion"
HS_X0_8 = "  Priest"
HS_X0_9 = "  Mage"
HS_X0_10 = "Equip."
HS_X0_11 = "Amigos"
HS_X0_12 = "Guilda"
HS_X0_13 = "Anterior"
HS_X0_14 = "Voltar"
HS_X0_15 = "AFK"
HS_X0_16 = "Indicar amigo"
HS_X0_18 = "Holy Suit"
HS_X0_19 = "Holy Stone"
HS_X0_20 = "Pets"
HS_X0_21 = "Dicas de pet"
HS_X0_22 = "Crescer e skills"
HS_X0_23 = "Profissões"
HS_X0_24 = "Montarias"
HS_X0_25 = "Bronze Suit"
HS_X0_26 = "Silver Suit"
HS_X0_27 = "Gold Suit"
HS_X0_28 = "Platinum Suit"
HS_X0_29 = "Mithril Suit"
HS_X0_30 = "Orichalcum Suit"
HS_X0_31 = "Adamantium Suit"
HS_X0_32 = "Esp. de Fogo"
HS_X0_33 = "Esp. de Água"


-- HelpSystemConfig.lua
-- 这个文件中文集中 请翻译这个文件

-- HelpSystemProc.lua

HSP_L0_1 = "GodsWar Online"
HSP_L0_2 = "Light Chop"
HSP_L0_3 = "Whirlwind"
HSP_L0_4 = "Flash Chop"
HSP_L0_5 = "Sword Storm"
HSP_L0_6 = "Steel Rain"
HSP_L0_7 = "Blood Claw"
HSP_L0_8 = "Rage Claw"
HSP_L0_9 = "Stun"
HSP_L0_10 = "Expose Armor"
HSP_L0_11 = "Holy Ward"
HSP_L0_12 = "Jab"
HSP_L0_13 = "Holy Jab"
HSP_L0_14 = "Stab"
HSP_L0_15 = "Rage Spear"
HSP_L0_16 = "Spear Hit"
HSP_L0_17 = "Ruined Strike"
HSP_L0_18 = "Chip Blast"
HSP_L0_19 = "Spear Blast"
HSP_L0_20 = "Meteor Blast"
HSP_L0_21 = "Sacred Zeal"
HSP_L0_22 = "Freeze"
HSP_L0_23 = "Heal"
HSP_L0_24 = "Area Heal"
HSP_L0_25 = "Gaia Care"
HSP_L0_26 = "Mana Shield"
HSP_L0_27 = "Shackle"
HSP_L0_28 = "Ice Shot"
HSP_L0_29 = "Windblade"
HSP_L0_30 = "Ice Cone"
HSP_L0_31 = "Dripstone"
HSP_L0_32 = "Holy Light"
HSP_L0_33 = "Stalagmite"
HSP_L0_34 = "Ternary Curse"
HSP_L0_35 = "Fireball"
HSP_L0_36 = "Lightball"
HSP_L0_37 = "Lightblade"
HSP_L0_38 = "Thunder"
HSP_L0_39 = "Fire Lotus"
HSP_L0_40 = "Star Shower"
HSP_L0_41 = "Thundercloud"
HSP_L0_42 = "Flame Blast"
HSP_L0_43 = "Fire Blast"
HSP_L0_44 = "Five-star Form"
HSP_L0_45 = "Silence"
HSP_L0_46 = "初级		  中级		  高级"
HSP_L0_47 = "初级		  中级		  高级		  大师级"
HSP_L0_48 = "初级		 中级		  高级		 大师级	   宗师级"
HSP_L0_49 = "任务第一层第一个按钮"
HSP_L0_50 = "任务第一层第二个按钮"
HSP_L0_51 = "任务第一层第三个按钮"
HSP_L0_52 = "技能第一层第一个按钮"
HSP_L0_53 = "技能第一层第二个按钮"
HSP_L0_54 = "技能第一层第三个按钮"
HSP_L0_55 = "任务第二层1第一个按钮"
HSP_L0_56 = "任务第二层1第二个按钮"
HSP_L0_57 = "任务第二层1第三个按钮"
HSP_L0_58 = "技能第二层1返回上一页按钮"
HSP_L0_59 = "技能第二层1按钮第二个按钮"
HSP_L0_60 = "技能第二层1按钮第三个按钮"
HSP_L0_61 = "任务第二层2第一个按钮"
HSP_L0_62 = "任务第二层2第二个按钮"
HSP_L0_63 = "任务第二层2第三个按钮"
HSP_L0_64 = "技能第二层2第一个按钮"
HSP_L0_65 = "技能第二层2第二个按钮"
HSP_L0_66 = "技能第二层2第三个按钮"
HSP_L0_67 = "任务第三层1的第二个按钮text"
HSP_L0_68 = "技能第三层1的第二个按钮text"
HSP_L0_69 = "任务第三层2第二层1第一个按钮text"
HSP_L0_70 = "任务第三层2第二层2第二个按钮text"
HSP_L0_71 = "技能第三层2第二层1第一个按钮text"
HSP_L0_72 = "技能第三层2第二层2第二个按钮text"
HSP_L0_74 = "Como consigo um pet?"
HSP_L0_75 = "Quais atributos os pets têm?"
HSP_L0_76 = "O que preciso para o pet aprender uma skill?"
HSP_L0_77 = "Como faço o Contrato da Alma com o pet?"
HSP_L0_78 = "Sobre a fusão de pets"
HSP_L0_79 = "Sobre o renascimento de pets"
HSP_L0_80 = "Roupa nova para o seu pet"
HSP_L0_81 = "Sobre as profissões"
HSP_L0_82 = "Tela de fabricação"
HSP_L0_83 = "Como conseguir os ingredientes"


-- HelpSystemSkillConfig.lua
-- 这个文件中文集中 请翻译这个文件

-- HotKey.xml

-- IntoneUI.xml

-- ItemCounterUI.xml

IC_X0_1 = "Máx."
IC_X0_2 = "Voltar"
IC_X0_3 = "Sim"
IC_X0_4 = "Não"
IC_X0_5 = "Equipamentos disponíveis"

-- ItemUI.xml

I_X0_1 = "Equip."
I_X0_2 = "Ver chapéu"
I_X0_3 = "Visual"
I_X0_4 = "Mostrar"
I_X0_5 = "Silver"
I_X0_6 = "Gold"
I_X0_7 = "Barraca"
I_X0_8 = "B-Gold"

--ItemBagsExUI.xml

IB_X0_1 = "Ver chapéu"
IB_X0_2 = "Trocar eq."
IB_X0_3 = "Pegar eq."
IB_X0_4 = "Salvar"
IB_X0_5 = "+ Mochila"
IB_X0_6 = "Nv. armad."
IB_X0_7 = "Nv. arma"
IB_X0_8 = "Trocar de equipamento com uma tecla"
IB_X0_9 = "Passar os equipamentos para a troca rápida"
IB_X0_10 = "Barraca"
IB_X0_11 = "Salvar eq."
IB_X0_12 = "Montarias"
IB_X0_13 = "Coroa da montaria"
IB_X0_14 = "Armadura da montaria"
IB_X0_15 = "Alma da montaria"
IB_X0_16 = "Sela da montaria"
IB_X0_17 = "Enfeite da montaria"


-- LevelExp.xml

-- LivingSkillUI.xml

LS_X0_1 = "当前任务"

-- LoginUI.lua
LS_X0_1 = "All Servers"
LS_X0_2 = "Servidor recomendado"
LS_X0_3 = "Servidor recomendado"
LS_X0_4 = "Todos os servidores"

-- LoginUI.xml

L_X0_1 = "Sair do jogo"
L_X0_2 = "Plug-in"
L_X0_3 = "Conta"
L_X0_4 = "Senha"
L_X0_5 = "Voltar"
L_X0_6 = "OK"
L_X0_7 = "Entrar"
L_X0_8 = "Excluir"
L_X0_9 = "Criar"
L_X0_10 = "Pronto"
L_X0_11 = "Nome :"
L_X0_12 = "Facção :"
L_X0_13 = "Classe :"
L_X0_14 = "Sexo :"
L_X0_15 = "Corpo :"
L_X0_16 = "Cabelo"
L_X0_17 = "Cor do cabelo"
L_X0_18 = "Rosto"
L_X0_19 = "GM"
L_X0_20 = "Áries"
L_X0_21 = "Touro"
L_X0_22 = "Gêmeos"
L_X0_23 = "Câncer"
L_X0_24 = "Leão"
L_X0_25 = "Virgem"
L_X0_26 = "Libra"
L_X0_27 = "Escorpião"
L_X0_28 = "Sagitário"
L_X0_29 = "Capricórnio"
L_X0_30 = "Aquário"
L_X0_31 = "Peixes"
L_X0_32 = "Zodíaco"
L_X0_33 = "ID de quem indicou       (opcional)"
L_X0_34 = "Voltar ao login"
L_X0_35 = "Último login"
L_X0_36 = "|cff00FF00●|cffFFFFFF Normal"
L_X0_37 = "|cffFFFF00●|cffFFFFFF Ocupado"
L_X0_38 = "|cffFF0000●|cffFFFFFF Cheio"
L_X0_39 = "|cffff4500★|cffFFFFFF servidores já usados"
L_X0_40 = "Recomendado"
L_X0_41 = "Confirmar"
L_X0_42 = "Mais servidores"
L_X0_43 = " IGG"
L_X0_44 = "facebook"
L_X0_45 = "Escolha a linha"
L_X0_46 = "Entre no Facebook primeiro"
L_X0_47 = "Escolha o reino"
L_X0_48 = "Servidor atual"

-- MallUIConfig.xml

MC_X0_1 = "Gold:"
MC_X0_2 = "Comprar"
MC_X0_3 = "Recarregar"
MC_X0_5 = "Itens do Mall ficam presos ao personagem nível 1-64."

-- Message.lua
-- 这个文件中文集中 请翻译这个文件

-- MessageBoxUI.xml

MB_X0_1 = "OK"
MB_X0_2 = "Cancelar"

-- MiniMap.xml

-- MiniMap_Template.xml

-- NewGodSkillUI.xml

NG_XO_1="GM"
NG_XO_2="Guia"

-- NewSkillUI.xml

-- NpcFun.lua

-- NpcFun.xml

NF_X0_1 = "描述字描述字描述字描述字"
NF_X0_2 = "OK"
NF_X0_3 = "Cancelar"
NF_X0_4 = "Sortear de novo"

-- NpcTalk.xml

-- NpcTrade.xml

NT_X0_1 = "Itens"

-- PersonalInfoUI.xml

PI_X0_1 = "Fé"
PI_X0_2 = "Athena"
PI_X0_3 = "战士战士"
PI_X0_4 = "Inspetor"
PI_X0_5 = "Guilda"
PI_X0_6 = "Cargo na guilda:"
PI_X0_7 = "Contrib."
PI_X0_8 = "Nível"
PI_X0_9 = "EXP"
PI_X0_10 = "Próx."
PI_X0_11 = "Desconhecido"
PI_X0_12 = "HP"
PI_X0_13 = "MP"
PI_X0_14 = "Ataque"
PI_X0_15 = "Defesa"
PI_X0_16 = "Atq. Mág"
PI_X0_17 = "Def. Mág"
PI_X0_18 = "Cura"
PI_X0_19 = "Acerto"
PI_X0_20 = "Esquiva"
PI_X0_21 = "Crítico"
PI_X0_22 = "Tenacid."
PI_X0_23 = "Dano Fís."
PI_X0_24 = "Dano Mág."
PI_X0_25 = "Absorção"
PI_X0_26 = "Nome"
PI_X0_27 = "Classe"
PI_X0_28 = "Reput."
PI_X0_29 = "Título"
PI_X0_30 = "Ocultar"
PI_X0_31 = "Guilda"
PI_X0_32 = "Cargo"
PI_X0_33 = "Honra"
PI_X0_34 = "Pontos"
PI_X0_35 = "Medalha"
PI_X0_36 = "Ocultar atributos"
-- PickupDropsUI.xml

PD_X0_1 = "Pegar tudo"

-- PlayerStates.xml

-- QuestInfoUI.xml

QI_X0_1 = "Missões"
QI_X0_2 = "Apagar"
QI_X0_3 = "Buscar"
QI_X0_4 = "Consultar"
QI_X0_5 = "Enviar pet"
QI_X0_6 = "[Pet enviado]"
QI_X0_7 = "Bônus de EXP"
QI_X0_8 = "Avaliar"

-- QuestViewUI.xml

QV_X1_1 = "Aceitar"
QV_X1_2 = "Recusar"
QV_X1_3 = "Concluir"
QV_X1_4 = "Cancelar"

--QuickEquipUI.xml

QE_X0_1 = "Pegar eq."
QE_X0_2 = "Aperte 'W' para trocar rápido"
QE_X0_3 = "Equip. reserva"

-- Relation.xml

R_X0_1 = "Amigos"
R_X0_2 = "Adicionar"
R_X0_3 = "Excluir"
R_X0_4 = "PM"
R_X0_5 = "Grupo"
R_X0_6 = "Bloquear"
R_X0_7 = "Adicionar"
R_X0_8 = "Digite o nome"
R_X0_9 = "OK"
R_X0_10 = "Cancelar"
R_X0_11 = "Aceitar"
R_X0_12 = "Recusar"
R_X0_13 = "Nome"
R_X0_14 = "Instância"
R_X0_15 = "Convidar"
R_X0_16 = "Expulsar"
R_X0_17 = "Mestre"
R_X0_18 = "Mestre:"
R_X0_19 = "Ética do mestre:"
R_X0_20 = "Ética do mestre no mês"
R_X0_21 = "Nomear"
R_X0_22 = "Inimigos"
R_X0_23 = "Tirar inim."


-- Revive.lua

-- ReviveUI.xml

R_X1_1 = "Você morreu"
R_X1_2 = "OK"
R_X1_3 = "Cancelar"
R_X1_4 = "Rev. Gold"
R_X1_5 = "Rev.Silver"
R_X1_6 = "Rev. grátis"


--RepQueUI.xml

RQ_X0_1 = "Você está na fila"
RQ_X0_2 = "Sair da fila"

--RookieGuide.xml
RG_X0_1 = "Tutorial do GodsDomain"
RG_X0_2 = "|cff436eeeDescrição da missão|cfffffff"
RG_X0_3 = "|cff436eeeGuia da missão|cfffffff"
RG_X0_4 = "Objetivo"
RG_X0_5 = "Prêmio"
RG_X0_6 = "Apagar missão"

--SkillChoice.xml
SKC_X0_1 = "Warrior"
SKC_X0_2 = "Champion"
SKC_X0_3 = "Priest"
SKC_X0_4 = "Mage"

--SkillTrain.xml
SKT_X0_1 = "Treinar ataque"
SKT_X0_2 = "Melhorar ataque"
SKT_X0_3 = "Treinar defesa"
SKT_X0_4 = "Melhorar defesa"
SKT_X0_5 = "Escolher skill"

-- SkillViewUI.xml

SV_X0_1 = "Skill"
SV_X0_2 = "Talento"
SV_X0_3 = "Pts. Talento:"
SV_X0_4 = "pts"

--SkillTrainProc.lua
ST_X0_1 = "Custo para ativar o espaço de skill:"
ST_X0_3 = "Espaço de skill ativado!"
ST_X0_4 = "Espaço de skill melhorado!"
ST_X0_5 = "Gasto"
ST_X0_6 = "Energia do Zodíaco: "
ST_X0_7 = "Pts. de Talento: "
ST_X0_8 = "Função inválida"
ST_X0_9 = "Ativar precisa de Gold"
ST_X0_10 = "Aumentar o ataque da skill escolhida:"
ST_X0_11 = "Coloque uma skill de defesa no espaço:"
ST_X0_12 = "Nível atual:"
ST_X0_13 = "MP gasto pela skill:"
ST_X0_14 = "Próximo nível:"
ST_X0_15 = "Melhorar o espaço precisa de"
ST_X0_16 = "|cFFFFFF00Energia do Zodíaco:"
ST_X0_17 = "Pts. de Talento:"
ST_X0_18 = "Grau do Zodíaco:"
ST_X0_19 = "Custo:"

-- StallBuyUI.xml

SB_X0_1 = "Comprar"
SB_X0_2 = "Cancelar"

-- StallCounterUI.xml

SC_X0_1 = "Máx."
SC_X0_2 = "Voltar"
SC_X0_3 = "Sim"
SC_X0_4 = "Não"

-- StallSellUI.xml

SS_X0_1 = "Mostrar itens"
SS_X0_2 = "Cancelar"
SS_X0_3 = "Tirar itens"

-- StatusUI.xml

-- StorageUI.xml

S_X0_1 = "Guardar"
S_X0_2 = "Retirar"
S_X0_3 = "Armazém"
S_X0_4 = "Prêmios"
S_X0_5 = "Prêmios não podem ser retirados da 1h às 3h todo dia"
S_X0_6 = "A câmera com as setas do teclado foi ligada, mas só funciona nas cidades, nos subúrbios e nas Pindus Mountains."
S_X0_7 = "A câmera com as setas do teclado foi desligada. Para ligar, é só clicar aqui."
S_X0_8 = "Armazém 1"
S_X0_9 = "Armazém 2"
S_X0_10 = "Armazém 3"
S_X0_11 = "Armazém 4"

-- SystemBar.lua

-- SystemBar.xml

SB_X1_1 = "Atributos"
SB_X1_2 = "Mochila"
SB_X1_3 = "Skills"
SB_X1_4 = "Missões"
SB_X1_5 = "Amigos"
SB_X1_6 = "Guilda"
SB_X1_7 = "Sistema"
SB_X1_8 = "Ajuda"
SB_X1_9 = "Forja"
SB_X1_10 = "AFK"
SB_X1_11 = "Site"
SB_X1_12 = "Ajuda"
SB_X1_13 = "Config."
SB_X1_14 = "Modo AFK (F12)"
SB_X1_15 = "Config. AFK"
SB_X1_16 = "Pet"
SB_X1_17 = "Skills(S)"
SB_X1_18 = "Talentos(S)"
SB_X1_19 = "Talento"
SB_X1_20 = "Iniciar"
SB_X1_21 = "Profissões(V)"

-- SystemSetupUI.xml

SS_X1_1 = "Vídeo"
SS_X1_2 = "Som"
SS_X1_3 = "Jogo"
SS_X1_4 = "Informações"
SS_X1_5 = "Sair do jogo"
SS_X1_6 = "Voltar ao jogo"
SS_X1_7 = "OK"
SS_X1_8 = "Cancelar"
SS_X1_9 = "Volume:"
SS_X1_10 = "Volume dos efeitos:"
SS_X1_11 = "Mín."
SS_X1_12 = "Máx."

--Specialmsg.xml

SM_X0_1 = "Info de troca"
SM_X0_2 = "Info de missão"
SM_X0_3 = "Info do grupo"
SM_X0_4 = "Info de PK"
SM_X0_5 = "Info da guilda"
SM_X0_6 = "Outras info"
SM_X0_7 = "Info do pet"
SM_X0_8 = "Info Zodíaco"

-- TargetInfo.xml

TI_X0_1 = "Menu"
TI_X0_2 = "Info"
TI_X0_3 = "Grupo"
TI_X0_4 = "Trocar"
TI_X0_5 = "Amigo"
TI_X0_6 = "PM"
TI_X0_7 = "Seguir"
TI_X0_8 = "Convidar"
TI_X0_9 = "Fé:"
TI_X0_10 = "Athena"
TI_X0_11 = "Classe:"
TI_X0_12 = "战士战士"
TI_X0_13 = "Reputação:"
TI_X0_14 = "Cargo:"
TI_X0_15 = "Inspetor"
TI_X0_16 = "Guilda:"
TI_X0_17 = "JoyConnectJoyConnect"
TI_X0_18 = "Cargo:"
TI_X0_19 = "JoyConnect"
TI_X0_20 = "Ataque:"
TI_X0_21 = "Defesa:"
TI_X0_22 = "Atq. Mág:"
TI_X0_23 = "Def. Mág:"
TI_X0_24 = "Dano Fís.:"
TI_X0_25 = "Dano Mág.:"
TI_X0_26 = "Acerto:"
TI_X0_27 = "Esquiva:"
TI_X0_28 = "Crítico:"
TI_X0_29 = "Tenacid.:"
TI_X0_30 = "Cura:"
TI_X0_31 = "Absorção:"
TI_X0_32 = "Ver pet"

-- TeamUI.xml

T_X0_1 = "Passar líder"
T_X0_2 = "Expulsar"
T_X0_3 = "Desfazer"
T_X0_4 = "Sair"
T_X0_5 = "Add amigo"
T_X0_6 = "PM"

-- TradeUI.xml

T_X1_1 = "OK"
T_X1_2 = "Cancelar"

--TakingPetProc.lua

TPP_X0_1 = "Chamar(L)"
TPP_X0_2 = "Recolher(L)"
TPP_X0_3 = "Enviar"
TPP_X0_4 = "Ficar (não liberado)"
TPP_X0_5 = "Seguir (não liberado)"
TPP_X0_6 = "Atacar (não liberado)"
TPP_X0_7 = "Facção travada"

-- UpGrade.xml

UG_X0_1 = "Site"
UG_X0_2 = "Ajuda"
UG_X0_3 = "Preencher"
UG_X0_4 = "Fechar"

-- UpGradeConfig.lua
-- 这个文件中文集中 请翻译这个文件

-- UpGradeProc.lua

-- WorldMapSetUI.xml

WMS_X0_1 = "Mostrar"
WMS_X0_2 = "Opções"
WMS_X0_3 = "Aliados"
WMS_X0_4 = "Inimigos"
WMS_X0_5 = "Guarda aliado"
WMS_X0_6 = "Guarda inimigo"
WMS_X0_7 = "Monstros"
WMS_X0_8 = "Área segura"
WMS_X0_9 = "Mapa-múndi"
WMS_X0_10 = "Minimapa"
-- LifeUI.xml

LF_X0_1 =  "Ferreiro"
LF_X0_2 =  " "
LF_X0_3 =  " "
LF_X0_4 =  " "
LF_X0_5 =  " "
LF_X0_6 =  " "
LF_X0_7 =  " "
LF_X0_8 =  " "
LF_X0_9 =  " "
LF_X0_10 = "Fazer armas"
LF_X0_11 = "Forjar armas"
LF_X0_12 = "Desmontar"
LF_X0_13 = " "
LF_X0_14 = " "
LF_X0_15 = " "
LF_X0_16 = "Skill Lethe"
LF_X0_17 = "Materiais necessários"
LF_X0_18 = "Produto final"
LF_X0_19 = "Chance"
LF_X0_20 = "Produzir"
LF_X0_21 = "OK"
LF_X0_22 = "Cancelar"
LF_X0_23 = "Nível"
LF_X0_24 = " "
LF_X0_25 = " "
LF_X0_26 = "Coloque o equipamento para desmontar"
LF_X0_27 = "Materiais obtidos"
LF_X0_28 = "Começar"
LF_X0_29 = "Retirar"
LF_X0_30 = " "
LF_X0_31 = " "
LF_X0_32 = " "
LF_X0_33 = " "
LF_X0_34 = " "
LF_X0_35 = " "
LF_X0_36 = " "
LF_X0_37 = " "
LF_X0_38 = " "
LF_X0_39 = " "
LF_X0_40 = " "


-- 宠物
-- PetUI.xml
PET_X0_1 = "Chamar"
PET_X0_2 = "Voltar"
PET_X0_3 = "Escolher"
PET_X0_4 = "Detalhes"
PET_X0_5 = "Soltar"
PET_X0_6 = "Sem nome"
PET_X0_7 = "Tarefa"
PET_X0_8 = "Nome:"
PET_X0_9 = "Nível:"
PET_X0_10 = "Fusão"

-- PetDetailUI.xml
PETD_X0_1 = "Nome:"
PETD_X0_2 = "Renomear"
PETD_X0_3 = "Raça:"
PETD_X0_4 = "Nature:"
PETD_X0_5 = "Skills:"
PETD_X0_6 = "Saciedade:"
PETD_X0_7 = "Amizade:"
PETD_X0_8 = "Idade:"
PETD_X0_9 = "Sexo:"
PETD_X0_10 = "Fusões:"
PETD_X0_11 = "HP"
PETD_X0_12 = "MP"
PETD_X0_13 = "Ataque"
PETD_X0_14 = "Defesa"
PETD_X0_15 = "Atq. Mág"
PETD_X0_16 = "Def. Mág"
PETD_X0_17 = "Cura"
PETD_X0_18 = "Acerto"
PETD_X0_19 = "Esquiva"
PETD_X0_20 = "Crítico"
PETD_X0_21 = "Tenacid."
PETD_X0_22 = "Dano Fís."
PETD_X0_23 = "Dano Mág."
PETD_X0_24 = "Absorção"
PETD_X0_25 = "Talentos:"
PETD_X0_26 = "Renomear"
PETD_X0_27 = "Fusão"
PETD_X0_28 = "Comida:"
PETD_X0_29 = "Contrato:"
PETD_X0_30 = "Não"
PETD_X0_31 = "Nível:"
PETD_X0_32 = "EXP atual:"
PETD_X0_33 = "EXP p/ subir:"
PETD_X0_34 = "Signo:"
PETD_X0_35 = "Fusão:"
PETD_X0_36 = "Renasc.:"
PETD_X0_37 = "Restam:"
PETD_X0_38 = "Rank:"
PETD_X0_39 = "(Valor base"
PETD_X0_40 = "Bônus)"
PETD_X0_41 = "Agil.:"
PETD_X0_42 = "Força:"
PETD_X0_43 = "Prec.:"
PETD_X0_44 = "Técn.:"
PETD_X0_45 = "Sab.:"
PETD_X0_46 = "Sorte:"
PETD_X0_47 = "Livre"
PETD_X0_48 = "Preso"
PETD_X0_49 = "Savvy"
PETD_X0_50 = "Situação:"
PETD_X0_51 = "Subir auto"
PETD_X0_52 = "Só aprende 1 de cada tipo"

--PetIndentureUI.xml
PETIN_X0_1 = "Contrato："
PETIN_X0_2 = "Sobre o Contrato da Alma"
PETIN_X0_3 = "Base aumentada"
PETIN_X0_4 = "Coloque |cff6CA6CD Contract Spirit |cffffffff para aumentar os pontos de savvy (máximo 5)"
PETIN_X0_5 = "Obs.: o Contrato da Alma |cffEE0000aumenta muito o savvy inicial do pet.|cffffffff Um contrato novo substitui o anterior."
PETIN_X0_6 = "Fazer contrato"

--PetWork.xml

PETW_X0_1 = "No GodsDomain, os pets são ótimos ajudantes. Tenha comida suficiente para eles e eles trarão bastante EXP e Pontos de Talento."
PETW_X0_2 = "Escolha como pagar a comida e o tempo de trabalho do pet."
PETW_X0_3 = "Custo previsto: "
PETW_X0_4 = "EXP ganha: "
PETW_X0_5 = "Talento ganho: "
PETW_X0_6 = "Pagar comida com:"
PETW_X0_7 = "Gold"
PETW_X0_8 = "Silver"
PETW_X0_9 = "Duração"
PETW_X0_10 = "1 hora"
PETW_X0_11 = "3 horas"
PETW_X0_12 = "8 horas"
PETW_X0_13 = "24 horas"
PETW_X0_14 = "Confirmar"
PETW_X0_15 = "Parar trabalho"
PETW_X0_16 = "Falta："
PETW_X0_17 = "Trabalho"
PETW_X0_18 = "Pagar custo:"
PETW_X0_19 = "Seu pet foi trabalhar e volta quando o tempo acabar. Se o trabalho for interrompido por qualquer motivo, você recebe só 20% do pagamento e o depósito não é devolvido. Pense bem!"

-- 宠物类型对应描述
PETTYPE1 = "Rock Elf";
PETTYPE2 = "Flower Pixie";
PETTYPE3 = "Minotaur";
PETTYPE4 = "Panda";
PETTYPE5 = "Easter Bunny";
PETTYPE6 = "Puppet";
PETTYPE7 = "Aviators";
PETTYPE8 = "Ghosts";
PETTYPE9 = "Mermaids";
PETTYPE10 = "Loyal Dog";
PETTYPE11 = "Tiger baby";
PETTYPE12 = "Blue Crystal Dragon"
PETTYPE13 = "Dodo";
PETTYPE14 = "Elf Guardian";
PETTYPE15 = "Wandering Spirit"
PETTYPE16 = "Young Yeti"
PETTYPE17 = "Sphinx";
PETTYPE18 = "Lil QT"
PETTYPE19 = "Impi"
PETTYPE20 = "Hell Hound"
PETTYPE21 = "Troodon"
PETTYPE22 = "Deadly Cactus"
PETTYPE23 = "Lil' Angel"
PETTYPE24 = "Kungfu Kid"
PETTYPE25 = "Crazed Bull"
PETTYPE26 = "Griffin"
PETTYPE27 = "Wildhog"
PETTYPE28 = "Spirit Cat"
PETTYPE29 = "Totoro"
PETTYPE30 = "Fox Spirit"
PETTYPE31 = "Platypus"
PETTYPE32 = "Hops"
PETTYPE33 = "Monkey"
PETTYPE34 = "Mouse"
PETTYPE35 = "Maneater Flower"
PETTYPE36 = "Penguin"
PETTYPE37 = "King Lion"
PETTYPE38 = "Thunder Pixie"
PETTYPE39 = "Bloodmoon Fox"
PETTYPE40 = "Kratortle"
PETTYPE41 = "Beelzeebub"
PETTYPE42 = "Billy Bear"
PETTYPE43 = "Roly Poly"
PETTYPE44 = "Hedgehog"
PETTYPE45 = "Cupid"
-- 资质对应描述
PETAPTITUDE1 = "|cFFFFFFFFCowish|cFFFFFFFF";
PETAPTITUDE2 = "|cFFFFFFFFCowish|cFFFFFFFF";
PETAPTITUDE3 = "|cFFFFFFFFCowish|cFFFFFFFF";
PETAPTITUDE4 = "|cFF00FCEDModerate|cFFFFFFFF";
PETAPTITUDE5 = "|cFF00FCEDRational|cFFFFFFFF";
PETAPTITUDE6 = "|cFF00FCEDRational|cFFFFFFFF";
PETAPTITUDE7 = "|cFFFFFF00Smart|cFFFFFFFF";
PETAPTITUDE8 = "|cFF00FF00Zealous|cFFFFFFFF";
PETAPTITUDE9 = "|cFF00FF00Grumpy|cFFFFFFFF";
PETAPTITUDE10 = "|cFF00FF00Brave|cFFFFFFFF";
PETAPTITUDE11 = "|cFF00FF00Brave|cFFFFFFFF";
PETAPTITUDE12 = "|cFF00FF00Brave|cFFFFFFFF";
PETAPTITUDE13 = "|cFFFF9900Almighty|cFFFFFFFF";
PETAPTITUDE14 = "|cFFE308E4Godly|cFFFFFFFF";
PETAPTITUDE15 = "Backup";
PETAPTITUDE16 = "Backup";
PETAPTITUDE17 = "Backup";
PETAPTITUDE18 = "Backup";
PETAPTITUDE19 = "Backup";
PETAPTITUDE20 = "Backup";

--PetDetailProc.lua

PETDP_X0_1 = "Satisfeito"
PETDP_X0_2 = "Cheio"
PETDP_X0_3 = "Com fome"
PETDP_X0_4 = "Faminto"
PETDP_X0_5 = "Leal"
PETDP_X0_6 = "Irmão"
PETDP_X0_7 = "Conhecido"
PETDP_X0_8 = "Estranho"
PETDP_X0_9 = "Filhote"
PETDP_X0_10 = "Jovem"
PETDP_X0_11 = "Adulto"
PETDP_X0_12 = "Velho"
PETDP_X0_13 = "Macho"
PETDP_X0_14 = "Fêmea"
PETDP_X0_15 = "Herbívoro"
PETDP_X0_16 = "Carnívoro"
PETDP_X0_17 = "Onívoro"
PETDP_X0_18 = "Desconhecido"
PETDP_X0_19 = "Se o pet comer algo que não é da dieta dele, a amizade não sobe e a saciedade sobe só a metade."
PETDP_X0_20 = "O contrato melhora o desempenho do pet. Um contrato novo substitui o antigo."
PETDP_X0_21 = "O pet tem uma habilidade especial"
PETDP_X0_22 = "Aumento de habilidade"
PETDP_X0_23 = "Quantas fusões este pet já fez"
PETDP_X0_24 = "Quantas vezes este pet renasceu"
PETDP_X0_25 = "Renascimentos que restam"
PETDP_X0_26 = "O Rank deixa as skills do pet mais fortes: quanto maior o Rank, mais forte."
PETDP_X0_27 = "O savvy inicial do pet pode subir com |cff6CA6CDfusão|cffffffff; o |cff6CA6CDrenascimento|cffffffff não muda ele."
PETDP_X0_28 = "O savvy extra sobe com os |cff6CA6CDníveis|cffffffff, mas o |cff6CA6CDrenascimento|cffffffff zera ele."
PETDP_X0_29 = "Aumenta o Acerto, o MP máximo, o Ataque Mágico e o dano refletido do pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_30 = "Aumenta o HP máximo, a Defesa Física e o roubo de vida do pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_31 = "Aumenta o Acerto, o Ataque Físico e a resistência mágica do pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_32 = "Aumenta a Esquiva, a resistência física e a resistência mágica do pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_33 = "Aumenta o HP máximo, o dano físico extra e diminui o dano crítico recebido pelo pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_34 = "Aumenta a absorção de dano, o dano mágico extra e o dano refletido do pet. Com o pet unido a você, esses bônus também passam para você."
PETDP_X0_35 = "Aumenta o HP máximo"
PETDP_X0_36 = "Aumenta o MP máximo"
PETDP_X0_37 = "Aumenta o acerto"
PETDP_X0_38 = "Aumenta a esquiva"
PETDP_X0_39 = "Aumenta o ataque físico"
PETDP_X0_40 = "Aumenta o ataque mágico"
PETDP_X0_41 = "Ataca com um dano físico fixo"
PETDP_X0_42 = "Ataca com um dano mágico fixo"
PETDP_X0_43 = "Aumenta a resistência a ataques físicos"
PETDP_X0_44 = "Aumenta a resistência a ataques mágicos"
PETDP_X0_45 = "Anula uma parte fixa do dano físico recebido"
PETDP_X0_46 = "Anula uma parte fixa do dano mágico recebido"
PETDP_X0_47 = "Absorve o dano recebido"
PETDP_X0_48 = "Anula uma parte fixa do dano crítico recebido"
PETDP_X0_49 = "Recupera sozinho depois de apanhar"
PETDP_X0_50 = "Devolve parte do dano recebido"
PETDP_X0_51 = "Pets presos não podem ser trocados."

--PetIndentureUI.lua
PETIN_X1_1 = "Fazer contrato"
PETIN_X1_2 = "Continuar"
PETIN_X1_3 = "Fechar"
PETIN_X1_4 = "(Inicial　+ bônus)"
PETIN_X1_5 = "Melhorar contrato"
PETIN_X1_6 = "Sobre o Contrato da Alma"
PETIN_X1_7 = "Efeito do Contrato da Alma"
PETIN_X1_8 = "Atributos do pet com contrato"
PETIN_X1_9 = "Herbívoro"
PETIN_X1_10 = "Carnívoro"
PETIN_X1_11 = "Onívoro"
PETIN_X1_12 = "Desconhecido"
PETIN_X1_13 = "Não"
PETIN_X1_14 = "|cffF14187 Sim"
PETIN_X1_15 = "Aumento fixo"
PETIN_X1_16 = "Aumento final"
PETIN_X1_17 = "Nv."

--PetInosculateUI.lua
PETINO_X0_1 = "|cffF14187 Coloque o pet principal"
PETINO_X0_2 = "|cffF14187 Coloque o pet que será fundido"
PETINO_X0_3 = "Não pode subir"
PETINO_X0_4 = "Fusão de pets"
PETINO_X0_5 = "Continuar"
PETINO_X0_6 = "Fechar"
PETINO_X0_7 = "(Inicial　+ bônus)"
PETINO_X0_8 = "Aumento"
PETINO_X0_9 = "Sobre a fusão"
PETINO_X0_10 = "Efeito da fusão"
PETINO_X0_11 = "Atributos depois da fusão"

--PetInosculateUI.xml
PETINO_X1_1 = "Coloque o pet principal"
PETINO_X1_2 = "Coloque o 2º pet"
PETINO_X1_3 = "A fusão aumenta o Rank e os 6 savvy iniciais do pet principal. Quanto mais forte o 2º pet, melhor. Os dois pets precisam ter nível 30 ou mais."
PETINO_X1_4 = "Sobre a fusão"
PETINO_X1_5 = "Rank:"
PETINO_X1_6 = "Sobre a fusão"
PETINO_X1_7 = "Coloque |cff6CA6CD Merge Spirit |cffffffff para melhorar a fusão (máximo 5)"
PETINO_X1_8 = "Obs.: na fusão |cffF14187o 2º pet é sacrificado para melhorar o savvy inicial do principal.|cffffffff Quanto maior o savvy do 2º pet, melhor o resultado."
PETINO_X1_9 = "Fusão de pets"
-- SrvMsg.lua
SM_L0_01 = "Uau, você é só nível"
SM_L0_02 = ", mas tem coragem de encarar a missão nível "
SM_L0_03 = "!"
SM_L0_04 = "Incrível! Você está quase no nível máximo e já pode fazer a missão de subir."
SM_L0_05 = "Jogador"
SM_L0_06 = "Ganha 10% a mais de EXP ao entregar uma missão concluída."
-- PetChangeName.xml
PETCN_X0_1 = "Você já renomeou este pet uma vez: agora precisa de Renaming Stone. Quer renomear?"
PETCN_X0_2 = "Digite o nome novo"


-- TakingPetUI.xml
PETTP_X0_1 = "Chamar"
PETTP_X0_2 = "Recolher"
PETTP_X0_3 = "Atacar"
PETTP_X0_4 = "Seguir"
PETTP_X0_5 = "Parar"

-- PetSkillUI.xml
PETS_X0_1 = "Auto"
--PetIntegrate.xml
PIG_XO_1 = "Sobre a união"
PIG_XO_2 = "HP"
PIG_XO_3 = "Acerto"
PIG_XO_4 = "Ataque Físico"
PIG_XO_5 = "+ Ataque Físico"
PIG_XO_6 = "Resist. Física"
PIG_XO_7 = "- Dano Físico"
PIG_XO_8 = "Absorção"
PIG_XO_9 = "Roubo de vida"
PIG_XO_10 = "MP"
PIG_XO_11 = "Esquiva"
PIG_XO_12 = "Ataque Mágico"
PIG_XO_13 = "+ Ataque Mágico"
PIG_XO_14 = "Resist. Mágica"
PIG_XO_15 = "- Dano Mágico"
PIG_XO_16 = "- Dano Crítico"
PIG_XO_17 = "Refletir Dano"

--PetSamsaraUI.lua

PETSAM_X0_1 = "Aumento aleatório"
PETSAM_X0_2 = "Aumento mínimo"
PETSAM_X0_3 = "Aumento pequeno"
PETSAM_X0_4 = "Aumento normal"
PETSAM_X0_5 = "Aumento grande"
PETSAM_X0_6 = "Aumento enorme"
PETSAM_X0_7 = "Renascer pet"
PETSAM_X0_8 = "Continuar"
PETSAM_X0_9 = "Fechar"
PETSAM_X0_10 = "Sobre o renascimento"
PETSAM_X0_11 = "Efeito do renascimento"
PETSAM_X0_12 = "Atributos depois de renascer"
PETSAM_X0_13 = "Crescimento acelerado"
PETSAM_X0_14 = "(Inicial　+ bônus)"
PETSAM_X0_15 = "Herbívoro"
PETSAM_X0_16 = "Carnívoro"
PETSAM_X0_17 = "Onívoro"
PETSAM_X0_18 = "Desconhecido"
PETSAM_X0_19 = "Não"
PETSAM_X0_20 = "Sim"

--PetSamsaraUI.xml

PETSAMU_X0_1 = "Sobre o renascimento"
PETSAMU_X0_2 = "Cresc. acel."
PETSAMU_X0_3 = "Coloque |cff6CA6CD Rebirth Spirit |cffffffff para o pet crescer mais rápido depois de renascer (máximo 5)"
PETSAMU_X0_4 = "Obs.: cada renascimento |cffEE0000 gasta 1 renascimento do pet |cffffffff! O pet volta para o nível 1 e |cffEE0000 cresce mais rápido |cffffffff! O savvy inicial fica igual, mas o savvy extra é perdido!"
PETSAMU_X0_5 = "Renascer pet"

--PetUnite.xml

PETUNI_X0_1 = "Sobre a união"
PETUNI_X0_2 = "HP"
PETUNI_X0_3 = "Acerto"
PETUNI_X0_4 = "Atq. fís."
PETUNI_X0_5 = "+Atq. fís."
PETUNI_X0_6 = "Res. fís."
PETUNI_X0_7 = "-Dano fís."
PETUNI_X0_8 = "Absorção"
PETUNI_X0_9 = "Roubo vida"
PETUNI_X0_10 = "MP"
PETUNI_X0_11 = "Esquiva"
PETUNI_X0_12 = "Atq. mág."
PETUNI_X0_13 = "+Atq. mág."
PETUNI_X0_14 = "Res. mág."
PETUNI_X0_15 = "-Dano mág."
PETUNI_X0_16 = "-Dano crít."
PETUNI_X0_17 = "Refletir"
PETUNI_X0_18 = "Acima está uma prévia do resultado, que depende do savvy do pet. Na união, o personagem ganha |cFFE3170D savvy do pet|cffffffff e |cFFE3170D skills do pet|cffffffff."
--RookieGuideProc.lua
RGP_L0_1 = "Missão recebida: "
RGP_L0_2 = "Missão feita"
RGP_L0_3 = "Prêmio: "
RGP_L0_4 = "Missão apagada: "
RGP_L0_5 = "Confirmar exclusão"
RGP_L0_6 = "Escolha uma missão"

--AnswersSystem.xml
ANSWERSY_X0_1 = "Continuar"
ANSWERSY_X0_2 = "Encerrar"
ANSWERSY_X0_3 = "Pegar prêmio"
ANSWERSY_X0_4 = "Respondendo perguntas simples você ganha bastante EXP e Pontos de Talento. A cada hora você pode fazer um quiz de 10 perguntas. Acertando as 10, ganha o prêmio todo; errando alguma, ganha metade. Cada quiz terminado dá chance de ganhar 200 Gold preso."
ANSWERSY_X0_5 = "Além disso, às |cFF32CD32 12:45 e 19:45|cffffffff tem o Quiz Valendo. Os 10 melhores ganham muitos Pontos de Talento."
ANSWERSY_X0_6 = "Ranking do Quiz"
ANSWERSY_X0_7 = "Quiz Valendo"
ANSWERSY_X0_8 = "|cFFE3170Ds |cffffffff para a próxima pergunta"
ANSWERSY_X0_9 = "Seus pontos: "

--AwardFunction.xml
AWARDF_X0_1 = "Ver"
AWARDF_X0_2 = "Pegar"
--AntiIndulge.xml
ATDG_X0_1 = "Digite o número do documento"
ATDG_X0_2 = "Depois"

--BeginnerGuideUI.xml
BEG_XO_1 = "Guia do iniciante"

--ApartLineUI.xml
AL_XO_1 = "你当前所在线路"
AL_XO_2 = "关闭"
AL_XO_3 = "切换线路"


--LiveSkillUI.xml
LSU_XO_1="Pts. ativid.:"
LSU_XO_2="Receitas:"
LSU_XO_3="Profissão:"
LSU_XO_4="EXP da prof.:"
LSU_XO_5="Para subir:"
LSU_XO_6="Itens:"
LSU_XO_7="Receitas:"
LSU_XO_8="Pts. gastos:"
LSU_XO_9="EXP ganha:"
LSU_XO_10="Chance:"
LSU_XO_11="Fabricar"
LSU_XO_12="Parar de fabricar"
LSU_XO_13="Chance das receitas:"
LSU_XO_14="O personagem precisa chegar a certo nível para a profissão continuar subindo."
LSU_XO_15="Cada receita usada dá EXP de profissão, desde que o nível da receita não seja muito baixo perto do nível da sua profissão."
LSU_XO_16="A chance depende do domínio da profissão: cada 5% de domínio a mais dá 1% a mais de chance nas receitas."

--GatherBox.xml
GBX_XO_1="Usando"
GBX_XO_2="Coleta de recursos,"
GBX_XO_3="Pts. ativid.:"
GBX_XO_4=" Parar coleta"

--BuyUI.xml
BY_XO_1="À venda"
BY_XO_2="Preço un."
BY_XO_3="Comprar"
BY_XO_4="itens"
BY_XO_5="Total"
BY_XO_6="Confirmar"

--StallBuyUI.xml
SBU_XO_1="Barraca"
SBU_XO_2="na loja"
SBU_XO_3="comprar"
SBU_XO_4="nome barraca"

--StallSellUI.xml
SSU_XO_1="Tirar tudo"
SSU_XO_2="Tirar"
SSU_XO_3="À venda"
SSU_XO_4="Cancelar"







